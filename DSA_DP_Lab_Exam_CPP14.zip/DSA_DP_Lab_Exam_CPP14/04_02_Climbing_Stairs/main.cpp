#include <bits/stdc++.h>
using namespace std;

int main() {
    int n;
    if (!(cin >> n) || n < 0) return 0;
    if (n > 90) {
        cout << "Input too large for 64-bit result\n";
        return 0;
    }

    unsigned long long a = 1, b = 1;
    for (int i = 2; i <= n; ++i) {
        unsigned long long c = a + b;
        a = b;
        b = c;
    }
    cout << (n == 0 ? 1 : (n == 1 ? 1 : b)) << '\n';
    return 0;
}
