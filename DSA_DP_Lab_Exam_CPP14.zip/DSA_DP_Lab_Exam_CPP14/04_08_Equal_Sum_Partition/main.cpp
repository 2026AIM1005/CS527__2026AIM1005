#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n < 0) return 0;
    vector<int> a(n);
    long long total = 0;
    for (int &x : a) {
        if (!(cin >> x) || x < 0) {
            cout << "Invalid input\n";
            return 0;
        }
        total += x;
    }

    if (total % 2) {
        cout << "Cannot be partitioned into equal-sum subsets\n";
        return 0;
    }
    long long target = total / 2;
    if (target > 2000000) {
        cout << "Target too large\n";
        return 0;
    }

    vector<char> dp((int)target + 1, false);
    dp[0] = true;
    for (int x : a) {
        for (int s = (int)target; s >= x; --s) {
            if (dp[s - x]) dp[s] = true;
        }
    }

    cout << (dp[target] ? "Can be partitioned into equal-sum subsets" :
                         "Cannot be partitioned into equal-sum subsets") << '\n';
    return 0;
}
