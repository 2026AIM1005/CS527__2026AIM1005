DSA DYNAMIC PROGRAMMING LAB EXAM - C++14
========================================

This ZIP contains 14 separate, input-driven C++14 programs.
All programs read values from standard input. No test data or answers are hardcoded.
The source files contain no explanatory comments.

FOLDER CONTENTS
---------------
01_Matrix_Chain_Multiplication
02_Rod_Cutting
03_01_Knapsack_01
03_02_Longest_Common_Subsequence
04_01_Fibonacci_DP
04_02_Climbing_Stairs
04_03_Minimum_Coin_Change
04_04_Coin_Change_Number_of_Ways
04_05_Longest_Increasing_Subsequence
04_06_Maximum_Sum_Non_Adjacent
04_07_Subset_Sum
04_08_Equal_Sum_Partition
04_09_Edit_Distance
04_10_Minimum_Path_Sum_Grid

COMPILATION AND RUNNING
-----------------------

Windows (MinGW g++)
1. Open PowerShell in the required program folder.
2. Compile:
   g++ -std=c++14 -O2 -Wall -Wextra main.cpp -o main.exe
3. Run:
   .\main.exe

Linux
1. Open a terminal in the required program folder.
2. Compile:
   g++ -std=c++14 -O2 -Wall -Wextra main.cpp -o main
3. Run:
   ./main

You can also provide input from a text file:
   Windows: .\main.exe < input.txt
   Linux:   ./main < input.txt

INPUT FORMATS
-------------

01 Matrix Chain Multiplication
   N
   p0 p1 ... pN
   Example:
   4
   10 20 30 40 30

02 Rod Cutting
   N
   price1 price2 ... priceN
   Example:
   8
   1 5 8 9 10 17 17 20

03 0-1 Knapsack
   N W
   value1 weight1
   ...
   valueN weightN
   Example:
   3 50
   60 10
   100 20
   120 30

04 Longest Common Subsequence
   string1 string2
   Example:
   ABCBDAB
   BDCABA

05 Fibonacci
   N
   F(0)=0 and F(1)=1. N must be at most 92 for a signed 64-bit result.

06 Climbing Stairs
   N
   Number of ways using steps of size 1 or 2. N must be at most 90.

07 Minimum Coin Change
   N
   coin1 coin2 ... coinN
   amount
   Example:
   3
   1 3 4
   6
   Each coin denomination must be positive. Unlimited use of each denomination.

08 Coin Change - Number of Ways
   N
   coin1 coin2 ... coinN
   amount
   Counts combinations, not different orderings. Unlimited use of each denomination.

09 Longest Increasing Subsequence
   N
   a1 a2 ... aN
   Finds a strictly increasing subsequence.

10 Maximum Sum of Non-Adjacent Elements
   N
   a1 a2 ... aN
   Selecting no elements is allowed, so the result is 0 if all values are negative.

11 Subset Sum
   N target
   a1 a2 ... aN
   Each non-negative array element can be selected at most once.

12 Equal Sum Partition
   N
   a1 a2 ... aN
   Checks whether non-negative elements can be split into two subsets with equal sum.

13 Edit Distance
   string1 string2
   Uses insertion, deletion, and replacement operations.

14 Minimum Path Sum in Grid
   rows columns
   grid values row by row
   Moves are allowed only right and down, from the top-left to bottom-right.

NOTES
-----
- Enter input in the format shown for the selected program.
- Each folder is independent and contains its own main.cpp.
- Use different test cases to check normal cases and edge cases.
- Some algorithms have memory/time proportional to input dimensions (for example, Knapsack is O(N*W)).
- The minimum path sum program accepts negative grid values too, provided movement remains right/down.
