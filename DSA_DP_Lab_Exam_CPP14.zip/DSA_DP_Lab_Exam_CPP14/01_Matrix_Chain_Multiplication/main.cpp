#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n <= 0) return 0;

    vector<long long> p(n + 1);
    for (auto &x : p) {
        if (!(cin >> x) || x <= 0) {
            cout << "Invalid input\n";
            return 0;
        }
    }

    const long long INF = LLONG_MAX / 4;
    vector<vector<long long>> dp(n + 1, vector<long long>(n + 1, 0));
    vector<vector<int>> split(n + 1, vector<int>(n + 1, 0));

    for (int len = 2; len <= n; ++len) {
        for (int i = 1; i + len - 1 <= n; ++i) {
            int j = i + len - 1;
            dp[i][j] = INF;
            for (int k = i; k < j; ++k) {
                __int128 cost = (__int128)dp[i][k] + dp[k + 1][j] + (__int128)p[i - 1] * p[k] * p[j];
                if (cost < dp[i][j]) {
                    dp[i][j] = (long long)cost;
                    split[i][j] = k;
                }
            }
        }
    }

    function<void(int,int)> printOrder = [&](int i, int j) {
        if (i == j) {
            cout << "A" << i;
            return;
        }
        cout << "(";
        printOrder(i, split[i][j]);
        cout << " x ";
        printOrder(split[i][j] + 1, j);
        cout << ")";
    };

    cout << "Minimum number of multiplications: " << dp[1][n] << '\n';
    cout << "Optimal parenthesization: ";
    printOrder(1, n);
    cout << '\n';
    return 0;
}
