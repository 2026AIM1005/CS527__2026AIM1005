#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, capacity;
    if (!(cin >> n >> capacity) || n < 0 || capacity < 0) return 0;

    vector<long long> value(n);
    vector<int> weight(n);
    for (int i = 0; i < n; ++i) {
        if (!(cin >> value[i] >> weight[i]) || weight[i] < 0) {
            cout << "Invalid input\n";
            return 0;
        }
    }

    vector<vector<long long>> dp(n + 1, vector<long long>(capacity + 1, 0));
    for (int i = 1; i <= n; ++i) {
        for (int w = 0; w <= capacity; ++w) {
            dp[i][w] = dp[i - 1][w];
            if (weight[i - 1] <= w) {
                dp[i][w] = max(dp[i][w], value[i - 1] + dp[i - 1][w - weight[i - 1]]);
            }
        }
    }

    vector<int> selected;
    int w = capacity;
    for (int i = n; i >= 1; --i) {
        if (dp[i][w] != dp[i - 1][w]) {
            selected.push_back(i);
            w -= weight[i - 1];
        }
    }
    reverse(selected.begin(), selected.end());

    cout << "Maximum Value: " << dp[n][capacity] << '\n';
    cout << "Selected item numbers: ";
    if (selected.empty()) cout << "None";
    else for (int i = 0; i < (int)selected.size(); ++i) {
        if (i) cout << ' ';
        cout << selected[i];
    }
    cout << '\n';
    return 0;
}
