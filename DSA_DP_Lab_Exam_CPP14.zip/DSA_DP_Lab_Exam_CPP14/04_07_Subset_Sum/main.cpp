#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, target;
    if (!(cin >> n >> target) || n < 0 || target < 0) return 0;
    vector<int> a(n);
    for (int &x : a) {
        if (!(cin >> x) || x < 0) {
            cout << "Invalid input\n";
            return 0;
        }
    }

    vector<char> dp(target + 1, false);
    dp[0] = true;
    for (int x : a) {
        for (int s = target; s >= x; --s) {
            if (dp[s - x]) dp[s] = true;
        }
    }

    cout << (dp[target] ? "Subset exists" : "Subset does not exist") << '\n';
    return 0;
}
