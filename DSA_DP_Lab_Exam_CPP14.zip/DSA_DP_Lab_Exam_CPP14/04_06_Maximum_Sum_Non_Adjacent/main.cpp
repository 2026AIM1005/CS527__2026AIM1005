#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n < 0) return 0;
    long long take = 0, skip = 0;

    for (int i = 0; i < n; ++i) {
        long long x;
        if (!(cin >> x)) return 0;
        long long newTake = skip + x;
        long long newSkip = max(skip, take);
        take = newTake;
        skip = newSkip;
    }

    cout << "Maximum sum: " << max(take, skip) << '\n';
    return 0;
}
