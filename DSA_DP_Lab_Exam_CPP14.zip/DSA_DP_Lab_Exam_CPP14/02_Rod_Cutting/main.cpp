#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n < 0) return 0;

    vector<long long> price(n + 1);
    for (int i = 1; i <= n; ++i) {
        if (!(cin >> price[i])) {
            cout << "Invalid input\n";
            return 0;
        }
    }

    vector<long long> dp(n + 1, 0);
    vector<int> firstCut(n + 1, 0);

    for (int len = 1; len <= n; ++len) {
        long long best = LLONG_MIN;
        for (int cut = 1; cut <= len; ++cut) {
            long long candidate = price[cut] + dp[len - cut];
            if (candidate > best) {
                best = candidate;
                firstCut[len] = cut;
            }
        }
        dp[len] = best;
    }

    cout << "Maximum Revenue: " << dp[n] << '\n';
    cout << "Cut lengths: ";
    if (n == 0) cout << "None";
    else {
        int rem = n;
        while (rem > 0) {
            cout << firstCut[rem];
            rem -= firstCut[rem];
            if (rem > 0) cout << ' ';
        }
    }
    cout << '\n';
    return 0;
}
