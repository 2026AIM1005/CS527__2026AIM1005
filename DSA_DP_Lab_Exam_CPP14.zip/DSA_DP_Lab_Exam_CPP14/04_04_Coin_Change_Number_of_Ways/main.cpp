#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n < 0) return 0;
    vector<int> coins(n);
    for (int &x : coins) {
        if (!(cin >> x) || x <= 0) {
            cout << "Invalid input\n";
            return 0;
        }
    }
    int amount;
    if (!(cin >> amount) || amount < 0) return 0;

    vector<unsigned long long> dp(amount + 1, 0);
    dp[0] = 1;
    for (int c : coins) {
        for (int x = c; x <= amount; ++x) dp[x] += dp[x - c];
    }

    cout << "Number of ways: " << dp[amount] << '\n';
    return 0;
}
