#include <bits/stdc++.h>
using namespace std;

int main() {
    long long n;
    if (!(cin >> n) || n < 0) return 0;
    if (n > 92) {
        cout << "Input too large for 64-bit result\n";
        return 0;
    }

    long long a = 0, b = 1;
    for (long long i = 0; i < n; ++i) {
        long long c = a + b;
        a = b;
        b = c;
    }
    cout << a << '\n';
    return 0;
}
