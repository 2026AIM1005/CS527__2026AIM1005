#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int rows, cols;
    if (!(cin >> rows >> cols) || rows <= 0 || cols <= 0) return 0;

    vector<vector<long long>> dp(rows, vector<long long>(cols));
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            long long x;
            if (!(cin >> x)) {
                cout << "Invalid input\n";
                return 0;
            }
            if (i == 0 && j == 0) dp[i][j] = x;
            else if (i == 0) dp[i][j] = dp[i][j - 1] + x;
            else if (j == 0) dp[i][j] = dp[i - 1][j] + x;
            else dp[i][j] = min(dp[i - 1][j], dp[i][j - 1]) + x;
        }
    }

    cout << "Minimum path sum: " << dp[rows - 1][cols - 1] << '\n';
    return 0;
}
