#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n < 0) return 0;
    vector<int> coins(n);
    for (int &x : coins) {
        if (!(cin >> x) || x <= 0) {
            cout << "Invalid input\n";
            return 0;
        }
    }
    int amount;
    if (!(cin >> amount) || amount < 0) return 0;

    const int INF = 1e9;
    vector<int> dp(amount + 1, INF), last(amount + 1, -1);
    dp[0] = 0;

    for (int x = 1; x <= amount; ++x) {
        for (int c : coins) {
            if (c <= x && dp[x - c] != INF && dp[x - c] + 1 < dp[x]) {
                dp[x] = dp[x - c] + 1;
                last[x] = c;
            }
        }
    }

    if (dp[amount] == INF) {
        cout << "Not Possible\n";
        return 0;
    }

    cout << "Minimum coins: " << dp[amount] << '\n';
    cout << "Coins used: ";
    int rem = amount;
    bool first = true;
    while (rem > 0) {
        if (!first) cout << ' ';
        cout << last[rem];
        rem -= last[rem];
        first = false;
    }
    if (first) cout << "None";
    cout << '\n';
    return 0;
}
