#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

static void serial_histogram(const int *a, long long n, long long hist[10]) {
    for (int b = 0; b < 10; ++b) hist[b] = 0;
    for (long long i = 0; i < n; ++i) ++hist[a[i]];
}

static void parallel_histogram(const int *a, long long n, long long hist[10]) {
    int max_threads = omp_get_max_threads();
    long long *local = calloc((size_t)max_threads * 10U, sizeof(*local));
    if (!local) { fprintf(stderr, "Histogram allocation failed.\n"); exit(1); }
    #pragma omp parallel
    {
        int tid = omp_get_thread_num();
        long long *mine = local + (size_t)tid * 10U;
        #pragma omp for schedule(static)
        for (long long i = 0; i < n; ++i) ++mine[a[i]];
    }
    for (int b = 0; b < 10; ++b) hist[b] = 0;
    for (int t = 0; t < max_threads; ++t)
        for (int b = 0; b < 10; ++b) hist[b] += local[(size_t)t * 10U + (size_t)b];
    free(local);
}

int main(void) {
    const long long sizes[] = {100000LL, 1000000LL, 10000000LL};
    const int threads[] = {1, 2, 4, 8};
    const int nt = (int)(sizeof(threads) / sizeof(threads[0]));
    omp_set_dynamic(0);
    printf("\nTASK 3 - HISTOGRAM (VALUES 0 TO 9)\n");
    printf("Race prevention: every thread updates a private 10-bin histogram; private histograms are combined after the parallel loop.\n");
    printf("%10s %8s %14s %10s %10s\n", "Size", "Threads", "Time (ms)", "Speedup", "Check");
    for (size_t s = 0; s < sizeof(sizes) / sizeof(sizes[0]); ++s) {
        long long n = sizes[s];
        int *a = malloc((size_t)n * sizeof(*a));
        if (!a) { fprintf(stderr, "Allocation failed.\n"); return 1; }
        for (long long i = 0; i < n; ++i) a[i] = (int)((i * 7LL + i / 13LL) % 10LL);
        long long expected[10], got[10];
        double t0 = omp_get_wtime(); serial_histogram(a, n, expected);
        double serial_ms = (omp_get_wtime() - t0) * 1000.0;
        for (int k = 0; k < nt; ++k) {
            omp_set_num_threads(threads[k]);
            t0 = omp_get_wtime(); parallel_histogram(a, n, got);
            double ms = (omp_get_wtime() - t0) * 1000.0;
            printf("%10lld %8d %14.3f %10.2f %10s\n", n, threads[k], ms, ms > 0.0 ? serial_ms / ms : 0.0, memcmp(expected, got, sizeof(expected)) == 0 ? "PASS" : "FAIL");
        }
        printf("  Histogram bins: ");
        for (int b = 0; b < 10; ++b) printf("%d:%lld%s", b, expected[b], b == 9 ? "\n" : "  ");
        free(a);
    }
    return 0;
}
