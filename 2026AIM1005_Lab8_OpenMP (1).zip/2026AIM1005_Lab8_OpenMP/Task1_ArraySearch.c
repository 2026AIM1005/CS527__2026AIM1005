#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

static int parallel_search(const int *a, long long n, int target) {
    long long found = n;
    #pragma omp parallel for reduction(min:found) schedule(static)
    for (long long i = 0; i < n; ++i) {
        if (a[i] == target && i < found) found = i;
    }
    return found == n ? -1 : (int)found;
}

int main(void) {
    const long long sizes[] = {100000LL, 1000000LL, 5000000LL};
    const int threads[] = {1, 2, 4, 8};
    const int nt = (int)(sizeof(threads) / sizeof(threads[0]));
    omp_set_dynamic(0);
    printf("\nTASK 1 - ARRAY SEARCH\n");
    printf("Target present: reports the first index; absent target: reports -1.\n");
    printf("%10s %8s %14s %14s %10s %10s\n", "Size", "Threads", "Index", "Time (ms)", "Speedup", "Check");
    for (size_t s = 0; s < sizeof(sizes) / sizeof(sizes[0]); ++s) {
        long long n = sizes[s];
        int *a = malloc((size_t)n * sizeof(*a));
        if (!a) { fprintf(stderr, "Allocation failed for %lld elements.\n", n); return 1; }
        for (long long i = 0; i < n; ++i) a[i] = (int)(i % 97);
        a[n - 1] = -7777;
        int target = -7777;
        double t0 = omp_get_wtime();
        int expected = -1;
        for (long long i = 0; i < n; ++i) if (a[i] == target) { expected = (int)i; break; }
        double serial_ms = (omp_get_wtime() - t0) * 1000.0;
        for (int k = 0; k < nt; ++k) {
            omp_set_num_threads(threads[k]);
            t0 = omp_get_wtime();
            int got = parallel_search(a, n, target);
            double ms = (omp_get_wtime() - t0) * 1000.0;
            printf("%10lld %8d %14d %14.3f %10.2f %10s\n", n, threads[k], got, ms, ms > 0.0 ? serial_ms / ms : 0.0, got == expected ? "PASS" : "FAIL");
        }
        int missing = parallel_search(a, n, -1001);
        printf("  Missing-target check (expected -1): %s\n", missing == -1 ? "PASS" : "FAIL");
        free(a);
    }
    return 0;
}
