#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

static void convolution_serial(const double *image, double *out, int n) {
    int m = n - 2;
    for (int i = 0; i < m; ++i) for (int j = 0; j < m; ++j) {
        double sum = 0.0;
        for (int ki = 0; ki < 3; ++ki) for (int kj = 0; kj < 3; ++kj)
            sum += image[(size_t)(i + ki) * (size_t)n + (size_t)(j + kj)];
        out[(size_t)i * (size_t)m + (size_t)j] = sum / 9.0;
    }
}

static int close_matrix(const double *a, const double *b, size_t n) {
    for (size_t i = 0; i < n; ++i) if (fabs(a[i] - b[i]) > 1e-9) return 0;
    return 1;
}

int main(void) {
    const int sizes[] = {128, 256, 512};
    const int threads[] = {1, 2, 4, 8};
    const int nt = (int)(sizeof(threads) / sizeof(threads[0]));
    omp_set_dynamic(0);
    printf("\nTASK 5 - 2D CONVOLUTION (3x3 AVERAGING FILTER)\n");
    printf("Valid positions only (no padding); output dimensions are (N-2) x (N-2).\n");
    printf("%8s %8s %14s %14s %10s %10s\n", "Image N", "Threads", "Time (ms)", "Serial (ms)", "Speedup", "Check");
    for (size_t s = 0; s < sizeof(sizes) / sizeof(sizes[0]); ++s) {
        int n = sizes[s], m = n - 2;
        size_t input_count = (size_t)n * (size_t)n, output_count = (size_t)m * (size_t)m;
        double *image = malloc(input_count * sizeof(*image));
        double *serial = malloc(output_count * sizeof(*serial));
        double *parallel = malloc(output_count * sizeof(*parallel));
        if (!image || !serial || !parallel) { fprintf(stderr, "Allocation failed.\n"); free(image); free(serial); free(parallel); return 1; }
        for (int i = 0; i < n; ++i) for (int j = 0; j < n; ++j) image[(size_t)i * (size_t)n + (size_t)j] = (double)((i * 10 + j * 3) % 256);
        double t0 = omp_get_wtime(); convolution_serial(image, serial, n);
        double serial_ms = (omp_get_wtime() - t0) * 1000.0;
        for (int k = 0; k < nt; ++k) {
            omp_set_num_threads(threads[k]);
            t0 = omp_get_wtime();
            #pragma omp parallel for collapse(2) schedule(static)
            for (int i = 0; i < m; ++i) for (int j = 0; j < m; ++j) {
                double sum = 0.0;
                for (int ki = 0; ki < 3; ++ki) for (int kj = 0; kj < 3; ++kj)
                    sum += image[(size_t)(i + ki) * (size_t)n + (size_t)(j + kj)];
                parallel[(size_t)i * (size_t)m + (size_t)j] = sum / 9.0;
            }
            double ms = (omp_get_wtime() - t0) * 1000.0;
            printf("%8d %8d %14.3f %14.3f %10.2f %10s\n", n, threads[k], ms, serial_ms, ms > 0.0 ? serial_ms / ms : 0.0, close_matrix(serial, parallel, output_count) ? "PASS" : "FAIL");
        }
        if (n == 128) {
            printf("  Example output (top-left 3x3 values):\n");
            for (int i = 0; i < 3; ++i) { for (int j = 0; j < 3; ++j) printf(" %8.2f", serial[(size_t)i * (size_t)m + (size_t)j]); printf("\n"); }
        }
        free(image); free(serial); free(parallel);
    }
    return 0;
}
