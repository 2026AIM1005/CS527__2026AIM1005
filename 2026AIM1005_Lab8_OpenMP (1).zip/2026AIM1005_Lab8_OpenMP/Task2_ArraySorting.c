#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <omp.h>

static void merge(int *a, int *tmp, long lo, long mid, long hi) {
    long i = lo, j = mid, k = lo;
    while (i < mid && j < hi) tmp[k++] = (a[i] <= a[j]) ? a[i++] : a[j++];
    while (i < mid) tmp[k++] = a[i++];
    while (j < hi) tmp[k++] = a[j++];
    for (i = lo; i < hi; ++i) a[i] = tmp[i];
}

static void merge_sort_serial(int *a, int *tmp, long lo, long hi) {
    if (hi - lo < 2) return;
    long mid = lo + (hi - lo) / 2;
    merge_sort_serial(a, tmp, lo, mid);
    merge_sort_serial(a, tmp, mid, hi);
    merge(a, tmp, lo, mid, hi);
}

static void merge_sort_parallel(int *a, int *tmp, long lo, long hi) {
    if (hi - lo < 2048) { merge_sort_serial(a, tmp, lo, hi); return; }
    long mid = lo + (hi - lo) / 2;
    #pragma omp task shared(a, tmp) firstprivate(lo, mid)
    merge_sort_parallel(a, tmp, lo, mid);
    #pragma omp task shared(a, tmp) firstprivate(mid, hi)
    merge_sort_parallel(a, tmp, mid, hi);
    #pragma omp taskwait
    merge(a, tmp, lo, mid, hi);
}

static int sorted_equal(const int *a, const int *b, long n) {
    for (long i = 0; i < n; ++i) if (a[i] != b[i]) return 0;
    return 1;
}

int main(void) {
    const long sizes[] = {10000L, 50000L, 100000L};
    const int threads[] = {1, 2, 4, 8};
    const int nt = (int)(sizeof(threads) / sizeof(threads[0]));
    omp_set_dynamic(0);
    printf("\nTASK 2 - PARALLEL MERGE SORT\n");
    printf("Synchronization: taskwait ensures both halves finish before merging; each task works on a separate half.\n");
    printf("%10s %8s %14s %14s %10s %10s\n", "Size", "Threads", "Time (ms)", "Serial (ms)", "Speedup", "Check");
    for (size_t s = 0; s < sizeof(sizes) / sizeof(sizes[0]); ++s) {
        long n = sizes[s];
        int *original = malloc((size_t)n * sizeof(*original));
        int *serial = malloc((size_t)n * sizeof(*serial));
        int *parallel = malloc((size_t)n * sizeof(*parallel));
        int *tmp = malloc((size_t)n * sizeof(*tmp));
        if (!original || !serial || !parallel || !tmp) { fprintf(stderr, "Allocation failed.\n"); free(original); free(serial); free(parallel); free(tmp); return 1; }
        srand(20261022U);
        for (long i = 0; i < n; ++i) original[i] = rand() % 100000;
        memcpy(serial, original, (size_t)n * sizeof(*serial));
        double t0 = omp_get_wtime();
        merge_sort_serial(serial, tmp, 0, n);
        double serial_ms = (omp_get_wtime() - t0) * 1000.0;
        for (int k = 0; k < nt; ++k) {
            memcpy(parallel, original, (size_t)n * sizeof(*parallel));
            omp_set_num_threads(threads[k]);
            t0 = omp_get_wtime();
            #pragma omp parallel
            {
                #pragma omp single
                merge_sort_parallel(parallel, tmp, 0, n);
            }
            double ms = (omp_get_wtime() - t0) * 1000.0;
            printf("%10ld %8d %14.3f %14.3f %10.2f %10s\n", n, threads[k], ms, serial_ms, ms > 0.0 ? serial_ms / ms : 0.0, sorted_equal(serial, parallel, n) ? "PASS" : "FAIL");
        }
        free(original); free(serial); free(parallel); free(tmp);
    }
    return 0;
}
