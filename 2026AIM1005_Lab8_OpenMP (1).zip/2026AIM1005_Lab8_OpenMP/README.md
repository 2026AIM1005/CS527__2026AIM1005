# CS527 Lab 8 — OpenMP Arrays and Matrices

This package implements the five tasks listed in `CS527 – Computer Systems, Lab 8: OpenMP — Arrays and Matrices`.

## Included tasks

1. **Array Search** — searches for a target and reports its first index, or `-1` when absent. The OpenMP loop uses `reduction(min:found)` so the smallest matching index is retained.
2. **Array Sorting** — parallel merge sort implemented with OpenMP tasks. `taskwait` synchronizes the two halves before merging. Tasks operate on separate array ranges.
3. **Histogram** — counts integers from 0 through 9. Each thread updates its own ten-bin histogram; the private histograms are combined after the parallel loop, avoiding a data race.
4. **Matrix Transpose** — uses `parallel for collapse(2)` to distribute matrix elements across threads.
5. **2D Convolution** — applies the PDF's 3×3 all-ones averaging filter, divides each sum by 9, and uses valid positions only (no padding). For an N×N input, the output is (N−2)×(N−2).

## Windows (PowerShell)

1. Extract the ZIP.
2. Open PowerShell in the extracted `CS527_Lab8_OpenMP_Final` folder.
3. Ensure GCC with OpenMP support is available in PATH (for example, MSYS2 MinGW-w64 GCC).
4. Run:

```powershell
.\run_all.bat
```

Choose task `1`–`5`. After each task finishes, press a key to return to the menu. Enter `0` to exit. The batch file compiles all programs with `-std=c11 -O2 -fopenmp -Wall -Wextra` before displaying the menu.

## Linux

From this folder, run:

```bash
chmod +x run_all.sh
./run_all.sh
```

Alternatively, compile all programs with `make`, then run any executable such as `./task1_search`. Use `make clean` to remove compiled executables.

## Correctness and timing

Each program compares its parallel result with a serial reference and prints `PASS` or `FAIL`. Timing output is formatted as tables. Each benchmark reports the input size, thread count, execution time, serial baseline where relevant, speedup, and correctness result. Speedup is calculated as serial time divided by parallel time; small workloads and system scheduling can make measured speedup lower than 1.

The assignment PDF does not specify benchmark sizes or thread counts. This package therefore uses these documented example sizes and thread counts 1, 2, 4, and 8:

- Array search: 100,000; 1,000,000; 5,000,000 elements.
- Merge sort: 10,000; 50,000; 100,000 elements.
- Histogram: 100,000; 1,000,000; 10,000,000 elements.
- Matrix transpose: 256×256; 512×512; 1024×1024.
- Convolution: 128×128; 256×256; 512×512 images.

Timings depend on the machine, compiler, and background load. Use the results printed on your own system in your lab submission; do not copy timing values from another computer.

## Compile commands

All commands use `-fopenmp -Wall` as required by the PDF. Example for an individual file:

```bash
gcc -std=c11 -O2 -fopenmp -Wall -Wextra Task1_ArraySearch.c -o task1_search
```

`-lm` is included for the convolution target in the Makefile for portability.
