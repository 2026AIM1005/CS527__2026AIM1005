#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
CC="${CC:-gcc}"
CFLAGS="-std=c11 -O2 -fopenmp -Wall -Wextra"
printf 'Compiling all five CS527 Lab 8 tasks...\n'
$CC $CFLAGS Task1_ArraySearch.c -o task1_search
$CC $CFLAGS Task2_ArraySorting.c -o task2_sort
$CC $CFLAGS Task3_Histogram.c -o task3_histogram
$CC $CFLAGS Task4_MatrixTranspose.c -o task4_transpose
$CC $CFLAGS Task5_Convolution.c -o task5_convolution
while true; do
  printf '\n============================================================\nCS527 Lab 8 - Select a task\n============================================================\n'
  printf '1. Array Search\n2. Parallel Merge Sort\n3. Histogram Calculation\n4. Matrix Transpose\n5. 2D Convolution\n0. Exit\nChoice: '
  read -r choice
  case "$choice" in
    1) ./task1_search ;;
    2) ./task2_sort ;;
    3) ./task3_histogram ;;
    4) ./task4_transpose ;;
    5) ./task5_convolution ;;
    0) echo 'Exiting Lab 8 menu.'; break ;;
    *) echo 'Invalid choice. Please enter 0 to 5.' ;;
  esac
done
