#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <omp.h>

static int same_matrix(const int *a, const int *b, size_t n) {
    for (size_t i = 0; i < n; ++i) if (a[i] != b[i]) return 0;
    return 1;
}

int main(void) {
    const int sizes[] = {256, 512, 1024};
    const int threads[] = {1, 2, 4, 8};
    const int nt = (int)(sizeof(threads) / sizeof(threads[0]));
    omp_set_dynamic(0);
    printf("\nTASK 4 - MATRIX TRANSPOSE\n");
    printf("Correctness compares every output element against the serial transpose.\n");
    printf("%8s %8s %14s %14s %10s %10s\n", "Rows", "Threads", "Time (ms)", "Serial (ms)", "Speedup", "Check");
    for (size_t s = 0; s < sizeof(sizes) / sizeof(sizes[0]); ++s) {
        int n = sizes[s]; size_t count = (size_t)n * (size_t)n;
        int *a = malloc(count * sizeof(*a));
        int *serial = malloc(count * sizeof(*serial));
        int *parallel = malloc(count * sizeof(*parallel));
        if (!a || !serial || !parallel) { fprintf(stderr, "Allocation failed.\n"); free(a); free(serial); free(parallel); return 1; }
        for (int i = 0; i < n; ++i) for (int j = 0; j < n; ++j) a[(size_t)i * (size_t)n + (size_t)j] = i * 3 + j * 7;
        double t0 = omp_get_wtime();
        for (int i = 0; i < n; ++i) for (int j = 0; j < n; ++j) serial[(size_t)j * (size_t)n + (size_t)i] = a[(size_t)i * (size_t)n + (size_t)j];
        double serial_ms = (omp_get_wtime() - t0) * 1000.0;
        for (int k = 0; k < nt; ++k) {
            omp_set_num_threads(threads[k]);
            t0 = omp_get_wtime();
            #pragma omp parallel for collapse(2) schedule(static)
            for (int i = 0; i < n; ++i) for (int j = 0; j < n; ++j) parallel[(size_t)j * (size_t)n + (size_t)i] = a[(size_t)i * (size_t)n + (size_t)j];
            double ms = (omp_get_wtime() - t0) * 1000.0;
            printf("%8d %8d %14.3f %14.3f %10.2f %10s\n", n, threads[k], ms, serial_ms, ms > 0.0 ? serial_ms / ms : 0.0, same_matrix(serial, parallel, count) ? "PASS" : "FAIL");
        }
        free(a); free(serial); free(parallel);
    }
    return 0;
}
