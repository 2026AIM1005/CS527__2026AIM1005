@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo CS527 Lab 8 - OpenMP Arrays and Matrices
echo ============================================================
where gcc >nul 2>nul
if errorlevel 1 (
  echo ERROR: gcc was not found in PATH. Install/use MSYS2 MinGW-w64 GCC with OpenMP support.
  pause
  exit /b 1
)
echo Compiling all five tasks...
gcc -std=c11 -O2 -fopenmp -Wall -Wextra Task1_ArraySearch.c -o task1_search.exe || goto compile_error
gcc -std=c11 -O2 -fopenmp -Wall -Wextra Task2_ArraySorting.c -o task2_sort.exe || goto compile_error
gcc -std=c11 -O2 -fopenmp -Wall -Wextra Task3_Histogram.c -o task3_histogram.exe || goto compile_error
gcc -std=c11 -O2 -fopenmp -Wall -Wextra Task4_MatrixTranspose.c -o task4_transpose.exe || goto compile_error
gcc -std=c11 -O2 -fopenmp -Wall -Wextra Task5_Convolution.c -o task5_convolution.exe || goto compile_error
:menu
cls
echo ============================================================
echo CS527 Lab 8 - Select a task
echo ============================================================
echo 1. Array Search
echo 2. Parallel Merge Sort
echo 3. Histogram Calculation
echo 4. Matrix Transpose
echo 5. 2D Convolution
echo 0. Exit
echo ============================================================
set /p choice=Enter your choice: 
if "%choice%"=="1" (task1_search.exe & pause & goto menu)
if "%choice%"=="2" (task2_sort.exe & pause & goto menu)
if "%choice%"=="3" (task3_histogram.exe & pause & goto menu)
if "%choice%"=="4" (task4_transpose.exe & pause & goto menu)
if "%choice%"=="5" (task5_convolution.exe & pause & goto menu)
if "%choice%"=="0" goto end
 echo Invalid choice. Please enter 0 to 5.
pause
goto menu
:compile_error
echo Compilation failed. Check the error above.
pause
exit /b 1
:end
echo Exiting Lab 8 menu.
endlocal
