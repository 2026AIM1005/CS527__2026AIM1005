@echo off
setlocal
cd /d "%~dp0"
echo ============================================================
echo CS527 Lab 9 - OpenMP
echo ============================================================
echo Compiling all three tasks...
gcc -O2 -std=c11 -fopenmp -Wall -Wextra Task1_ParallelMergeSort.c -o task1.exe
if errorlevel 1 goto compile_error
gcc -O2 -std=c11 -fopenmp -Wall -Wextra Task2_OpenMPScheduling.c -o task2.exe
if errorlevel 1 goto compile_error
gcc -O2 -std=c11 -fopenmp -Wall -Wextra Task3_EvenOddReduction.c -o task3.exe
if errorlevel 1 goto compile_error
:menu
cls
echo ============================================================
echo CS527 Lab 9 - OpenMP Menu
echo ============================================================
echo 1. Recursive parallel merge sort
echo 2. Static, dynamic and guided scheduling
echo 3. Even/odd count: reduction vs atomic
echo 0. Exit
echo ============================================================
set /p choice=Enter your choice: 
if "%choice%"=="1" (
    task1.exe
    pause
    goto menu
)
if "%choice%"=="2" (
    task2.exe
    pause
    goto menu
)
if "%choice%"=="3" (
    task3.exe
    pause
    goto menu
)
if "%choice%"=="0" goto end
echo Invalid choice.
pause
goto menu
:compile_error
echo Compilation failed. Check the compiler error above.
pause
exit /b 1
:end
endlocal
