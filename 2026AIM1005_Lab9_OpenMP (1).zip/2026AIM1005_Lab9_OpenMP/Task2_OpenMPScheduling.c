#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

static void calculate_value(long i, double input, double *result) {
    int work = (int)((i % 1000L) / 100L) + 1;
    double x = input;
    for (int j = 0; j < work; ++j) x = x * 1.0000001 + 0.0000001;
    *result = x;
}

static int same_results(const double *a, const double *b, long n) {
    for (long i = 0; i < n; ++i) if (a[i] != b[i]) return 0;
    return 1;
}

int main(void) {
    const long sizes[] = {100000L, 1000000L, 10000000L};
    const int thread_counts[] = {1, 2, 4, 8};
    const int repeats[] = {50, 10, 3};
    puts("\nTASK 2 - OPENMP SCHEDULING COMPARISON");
    puts("Uneven work per element: 1 to 10 dependent floating-point iterations.");
    puts("Times are average seconds per run; repetitions increase for smaller inputs.");
    printf("%-10s %-12s %-8s %-10s %-12s %-12s %-10s %-10s %-7s\n", "N", "Schedule", "Threads", "Runs", "Time(s)", "Serial(s)", "Speedup", "Efficiency", "Verify");
    omp_set_dynamic(0);
    for (size_t si = 0; si < sizeof(sizes) / sizeof(sizes[0]); ++si) {
        long n = sizes[si];
        int reps = repeats[si];
        double *input = malloc((size_t)n * sizeof(double));
        double *serial = malloc((size_t)n * sizeof(double));
        double *output = malloc((size_t)n * sizeof(double));
        if (!input || !serial || !output) {
            fprintf(stderr, "Allocation failed for N=%ld.\n", n);
            free(input); free(serial); free(output); return 1;
        }
        for (long i = 0; i < n; ++i) input[i] = (double)i * 0.001;
        double start = omp_get_wtime();
        for (int r = 0; r < reps; ++r)
            for (long i = 0; i < n; ++i) calculate_value(i, input[i], &serial[i]);
        double serial_time = (omp_get_wtime() - start) / reps;
        for (int ti = 0; ti < 4; ++ti) {
            int threads = thread_counts[ti];
            omp_set_num_threads(threads);
            for (int strategy = 0; strategy < 3; ++strategy) {
                double elapsed_total = 0.0;
                for (int r = 0; r < reps; ++r) {
                    double t0 = omp_get_wtime();
                    if (strategy == 0) {
                        #pragma omp parallel for schedule(static)
                        for (long i = 0; i < n; ++i) calculate_value(i, input[i], &output[i]);
                    } else if (strategy == 1) {
                        #pragma omp parallel for schedule(dynamic, 100)
                        for (long i = 0; i < n; ++i) calculate_value(i, input[i], &output[i]);
                    } else {
                        #pragma omp parallel for schedule(guided)
                        for (long i = 0; i < n; ++i) calculate_value(i, input[i], &output[i]);
                    }
                    elapsed_total += omp_get_wtime() - t0;
                }
                double elapsed = elapsed_total / reps;
                const char *name = strategy == 0 ? "static" : (strategy == 1 ? "dynamic,100" : "guided");
                double speedup = elapsed > 0.0 ? serial_time / elapsed : 0.0;
                printf("%-10ld %-12s %-8d %-10d %-12.6f %-12.6f %-10.3f %-10.3f %s\n", n, name, threads, reps, elapsed, serial_time, speedup, speedup / threads, same_results(serial, output, n) ? "PASS" : "FAIL");
            }
        }
        free(input); free(serial); free(output);
    }
    return 0;
}
