# CS527 Lab 9 — OpenMP

This folder implements the three tasks in the supplied Lab 9 PDF:

1. Recursive merge sort using OpenMP tasks and `taskwait`, with a serial cutoff.
2. Uneven per-element workload using `schedule(static)`, `schedule(dynamic, 100)`, and `schedule(guided)`.
3. Even/odd counting using `reduction(+:even_count, odd_count)` and OpenMP atomic updates.

## Windows (PowerShell)

1. Extract the ZIP.
2. Install GCC with OpenMP support (for example, the MSYS2 MinGW-w64 GCC toolchain) and ensure `gcc` is on PATH.
3. In this folder, run:

```powershell
.\run_all.bat
```

Choose 1, 2, or 3. Enter 0 to exit. The wrapper compiles each program using `-O2 -std=c11 -fopenmp -Wall -Wextra` before showing the menu.

## Linux

```bash
chmod +x run_all.sh
./run_all.sh
```

Alternatively, use `make` to compile and `make clean` to remove compiled binaries.

## Benchmarks and correctness

- Task 1 tests N = 100,000, 1,000,000, and 10,000,000 with 1, 2, 4, and 8 threads. Each timing is averaged over three runs.
- Task 2 tests the same three sizes and thread counts for static, dynamic (chunk 100), and guided scheduling. The workload varies from 1 to 10 dependent floating-point iterations per element. Small sizes repeat the same deterministic operation multiple times to reduce timer-resolution noise; output times are reported as average seconds per run.
- Task 3 tests N = 100,000, 1,000,000, 10,000,000, and 100,000,000 with 1, 2, 4, and 8 threads. Small sizes repeat counting multiple times to reduce timer-resolution noise; output times are reported as average seconds per run.
- Each table reports elapsed time, serial baseline time, speedup, efficiency, and a correctness check. Speedup is serial baseline time divided by parallel-method time. Efficiency is speedup divided by the thread count.
- The serial baseline is measured separately for each input size and uses the same deterministic input data. `PASS` means the parallel result matched the serial result.
- Timings are machine-dependent. OpenMP startup and synchronization overhead may make parallel execution slower for small inputs. Do not alter measured timings; report the values produced on the computer used for submission.

## Report questions — suggested answers

### Task 1: Recursive task parallelism

- **OpenMP tasks vs. `parallel for`:** `parallel for` distributes loop iterations among threads. Tasks create units of work dynamically and suit recursive algorithms where the work tree is not a simple loop.
- **Why `taskwait` is needed:** The parent must wait until both child halves have finished sorting before merging them; otherwise the merge can read unfinished data.
- **Cutoff threshold:** A cutoff avoids creating many tiny tasks. A larger cutoff reduces task overhead but may leave less work available for parallel execution; the best value depends on the machine and input.
- **Why small arrays can be slower in parallel:** Thread startup, task creation, scheduling, and synchronization can cost more than the sorting work itself.
- **Task creation overhead:** Excessive tasks consume runtime resources and reduce useful work per task, limiting scalability.

### Task 2: Scheduling strategies

- **Static:** Iterations are assigned in advance with low scheduling overhead; often good for uniform work.
- **Dynamic:** Threads request additional chunks as they finish; this balances uneven work better but adds scheduling overhead.
- **Guided:** Assigns larger chunks initially and gradually smaller chunks, attempting to balance overhead and load balancing.
- **Uniform vs. uneven work:** Static is often efficient for uniform work. Dynamic or guided may improve load balance when iteration costs vary; actual results depend on workload and hardware.
- **Dynamic overhead and chunk size:** Frequent chunk requests cost time. Small chunks improve balance but increase scheduling overhead; large chunks reduce overhead but can leave some threads waiting.

### Task 3: Multiple reductions

- **Multiple variables:** List all variables with the same reduction operator, e.g. `reduction(+:even_count, odd_count)`.
- **Reduction vs. atomic:** Reduction gives each thread private counters and combines them after the loop, reducing contention. Atomic updates serialize competing updates to shared counters.
- **Why counts sum to N:** Every array element is either even or odd, and each element increments exactly one counter; therefore `even_count + odd_count == N`.
- **Do more threads always help?** No. Memory bandwidth limits, scheduling, synchronization, serial work, and small inputs can limit gains or make execution slower.

## Sizes

The PDF's sizes are interpreted as powers of ten: `10^5`, `10^6`, `10^7`, and `10^8` correspond to 100,000, 1,000,000, 10,000,000, and 100,000,000 elements, as applicable to each task.
