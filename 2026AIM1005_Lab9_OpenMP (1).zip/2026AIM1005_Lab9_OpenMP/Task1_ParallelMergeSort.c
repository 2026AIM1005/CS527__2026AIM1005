#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

#define CUTOFF 2048
#define BENCH_REPEATS 3

static unsigned int next_value(unsigned int *state) {
    *state ^= *state << 13;
    *state ^= *state >> 17;
    *state ^= *state << 5;
    return *state;
}

static void merge(int *a, int *tmp, long left, long mid, long right) {
    long i = left, j = mid + 1, k = left;
    while (i <= mid && j <= right)
        tmp[k++] = (a[i] <= a[j]) ? a[i++] : a[j++];
    while (i <= mid) tmp[k++] = a[i++];
    while (j <= right) tmp[k++] = a[j++];
    for (i = left; i <= right; ++i) a[i] = tmp[i];
}

static void merge_sort_serial(int *a, int *tmp, long left, long right) {
    if (left >= right) return;
    long mid = left + (right - left) / 2;
    merge_sort_serial(a, tmp, left, mid);
    merge_sort_serial(a, tmp, mid + 1, right);
    merge(a, tmp, left, mid, right);
}

static void merge_sort_parallel(int *a, int *tmp, long left, long right) {
    if (left >= right) return;
    if (right - left < CUTOFF) {
        merge_sort_serial(a, tmp, left, right);
        return;
    }
    long mid = left + (right - left) / 2;
    #pragma omp task shared(a, tmp) firstprivate(left, mid)
    merge_sort_parallel(a, tmp, left, mid);
    #pragma omp task shared(a, tmp) firstprivate(mid, right)
    merge_sort_parallel(a, tmp, mid + 1, right);
    #pragma omp taskwait
    merge(a, tmp, left, mid, right);
}

static int is_sorted(const int *a, long n) {
    for (long i = 1; i < n; ++i) if (a[i - 1] > a[i]) return 0;
    return 1;
}

int main(void) {
    const long sizes[] = {100000L, 1000000L, 10000000L};
    const int thread_counts[] = {1, 2, 4, 8};
    puts("\nTASK 1 - PARALLEL MERGE SORT (OpenMP tasks)");
    printf("Cutoff: %d elements; each timing is averaged over %d runs.\n", CUTOFF, BENCH_REPEATS);
    printf("%-10s %-8s %-12s %-12s %-10s %-10s %-7s\n", "N", "Threads", "Serial(s)", "Parallel(s)", "Speedup", "Efficiency", "Verify");
    omp_set_dynamic(0);
    for (size_t si = 0; si < sizeof(sizes) / sizeof(sizes[0]); ++si) {
        long n = sizes[si];
        int *source = malloc((size_t)n * sizeof(int));
        int *serial = malloc((size_t)n * sizeof(int));
        int *parallel = malloc((size_t)n * sizeof(int));
        int *tmp = malloc((size_t)n * sizeof(int));
        if (!source || !serial || !parallel || !tmp) {
            fprintf(stderr, "Allocation failed for N=%ld.\n", n);
            free(source); free(serial); free(parallel); free(tmp); return 1;
        }
        unsigned int state = 0x1234567u;
        for (long i = 0; i < n; ++i) source[i] = (int)(next_value(&state) % 1000000u);
        double serial_total = 0.0;
        for (int r = 0; r < BENCH_REPEATS; ++r) {
            for (long i = 0; i < n; ++i) serial[i] = source[i];
            double t0 = omp_get_wtime();
            merge_sort_serial(serial, tmp, 0, n - 1);
            serial_total += omp_get_wtime() - t0;
        }
        double serial_time = serial_total / BENCH_REPEATS;
        for (int ti = 0; ti < 4; ++ti) {
            int threads = thread_counts[ti];
            double parallel_total = 0.0;
            int valid = 1;
            for (int r = 0; r < BENCH_REPEATS; ++r) {
                for (long i = 0; i < n; ++i) parallel[i] = source[i];
                omp_set_num_threads(threads);
                double t0 = omp_get_wtime();
                #pragma omp parallel
                {
                    #pragma omp single
                    merge_sort_parallel(parallel, tmp, 0, n - 1);
                }
                parallel_total += omp_get_wtime() - t0;
                if (!is_sorted(parallel, n) || !is_sorted(serial, n)) valid = 0;
                for (long i = 0; valid && i < n; ++i) if (parallel[i] != serial[i]) valid = 0;
            }
            double parallel_time = parallel_total / BENCH_REPEATS;
            double speedup = parallel_time > 0.0 ? serial_time / parallel_time : 0.0;
            printf("%-10ld %-8d %-12.6f %-12.6f %-10.3f %-10.3f %s\n", n, threads, serial_time, parallel_time, speedup, speedup / threads, valid ? "PASS" : "FAIL");
        }
        free(source); free(serial); free(parallel); free(tmp);
    }
    return 0;
}
