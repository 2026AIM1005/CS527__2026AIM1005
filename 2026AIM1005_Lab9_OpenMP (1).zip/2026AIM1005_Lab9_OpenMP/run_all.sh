#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
CC=${CC:-gcc}
CFLAGS="-O2 -std=c11 -fopenmp -Wall -Wextra"
echo "Compiling all three CS527 Lab 9 tasks..."
$CC $CFLAGS Task1_ParallelMergeSort.c -o task1
$CC $CFLAGS Task2_OpenMPScheduling.c -o task2
$CC $CFLAGS Task3_EvenOddReduction.c -o task3
while true; do
    echo "============================================================"
    echo "CS527 Lab 9 - OpenMP Menu"
    echo "1. Recursive parallel merge sort"
    echo "2. Static, dynamic and guided scheduling"
    echo "3. Even/odd count: reduction vs atomic"
    echo "0. Exit"
    read -r -p "Enter your choice: " choice
    case "$choice" in
        1) ./task1; read -r -p "Press Enter to return to menu..." ;;
        2) ./task2; read -r -p "Press Enter to return to menu..." ;;
        3) ./task3; read -r -p "Press Enter to return to menu..." ;;
        0) exit 0 ;;
        *) echo "Invalid choice." ;;
    esac
done
