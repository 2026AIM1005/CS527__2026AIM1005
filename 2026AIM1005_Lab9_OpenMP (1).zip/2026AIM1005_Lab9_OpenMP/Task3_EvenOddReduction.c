#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

int main(void) {
    const long sizes[] = {100000L, 1000000L, 10000000L, 100000000L};
    const int thread_counts[] = {1, 2, 4, 8};
    const int repeats[] = {50, 5, 2, 1};
    puts("\nTASK 3 - EVEN/ODD COUNTS: REDUCTION VS ATOMIC");
    puts("Times are average seconds per run; repetitions increase for smaller inputs.");
    printf("%-12s %-12s %-8s %-8s %-12s %-12s %-10s %-10s %-7s\n", "N", "Method", "Threads", "Runs", "Time(s)", "Serial(s)", "Speedup", "Efficiency", "Verify");
    omp_set_dynamic(0);
    for (size_t si = 0; si < sizeof(sizes) / sizeof(sizes[0]); ++si) {
        long n = sizes[si];
        int reps = repeats[si];
        int *a = malloc((size_t)n * sizeof(int));
        if (!a) { fprintf(stderr, "Allocation failed for N=%ld.\n", n); return 1; }
        for (long i = 0; i < n; ++i) a[i] = (int)((i * 1103515245ULL + 12345ULL) % 1000ULL);
        long long serial_even = 0, serial_odd = 0;
        double start = omp_get_wtime();
        for (int r = 0; r < reps; ++r) {
            long long even = 0, odd = 0;
            for (long i = 0; i < n; ++i) {
                if (a[i] % 2 == 0) ++even; else ++odd;
            }
            serial_even = even;
            serial_odd = odd;
        }
        double serial_time = (omp_get_wtime() - start) / reps;
        for (int ti = 0; ti < 4; ++ti) {
            int threads = thread_counts[ti];
            for (int method = 0; method < 2; ++method) {
                long long even_count = 0, odd_count = 0;
                omp_set_num_threads(threads);
                double start_method = omp_get_wtime();
                for (int r = 0; r < reps; ++r) {
                    even_count = 0;
                    odd_count = 0;
                    if (method == 0) {
                        #pragma omp parallel for reduction(+:even_count, odd_count)
                        for (long i = 0; i < n; ++i) {
                            if (a[i] % 2 == 0) ++even_count; else ++odd_count;
                        }
                    } else {
                        #pragma omp parallel for
                        for (long i = 0; i < n; ++i) {
                            if (a[i] % 2 == 0) {
                                #pragma omp atomic update
                                even_count++;
                            } else {
                                #pragma omp atomic update
                                odd_count++;
                            }
                        }
                    }
                }
                double elapsed = (omp_get_wtime() - start_method) / reps;
                int valid = even_count == serial_even && odd_count == serial_odd && even_count + odd_count == n;
                double speedup = elapsed > 0.0 ? serial_time / elapsed : 0.0;
                printf("%-12ld %-12s %-8d %-8d %-12.6f %-12.6f %-10.3f %-10.3f %s\n", n, method == 0 ? "reduction" : "atomic", threads, reps, elapsed, serial_time, speedup, speedup / threads, valid ? "PASS" : "FAIL");
            }
        }
        free(a);
    }
    return 0;
}
