#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

static void run_case(long long n) {
    int *a = malloc((size_t)n * sizeof(int));
    int *b = malloc((size_t)n * sizeof(int));
    int *serial = malloc((size_t)n * sizeof(int));
    int *parallel = malloc((size_t)n * sizeof(int));
    if (!a || !b || !serial || !parallel) {
        printf("Memory allocation failed for N=%lld\n", n);
        free(a); free(b); free(serial); free(parallel);
        return;
    }

    for (long long i = 0; i < n; ++i) {
        a[i] = (int)(i % 1000);
        b[i] = (int)((i * 3) % 1000);
    }

    double start = omp_get_wtime();
    for (long long i = 0; i < n; ++i) serial[i] = a[i] + b[i];
    double serial_time = omp_get_wtime() - start;

    printf("\nTASK 1: VECTOR ADDITION | N=%lld | Serial: %.6f s\n", n, serial_time);
    printf("+---------+------------------+----------+-------------+\n");
    printf("| Threads | Parallel Time(s) | Speedup  | Match       |\n");
    printf("+---------+------------------+----------+-------------+\n");

    int thread_counts[] = {1, 2, 4, 8};
    for (int t = 0; t < 4; ++t) {
        int threads = thread_counts[t];
        start = omp_get_wtime();
        #pragma omp parallel for num_threads(threads)
        for (long long i = 0; i < n; ++i) parallel[i] = a[i] + b[i];
        double elapsed = omp_get_wtime() - start;

        int match = 1;
        for (long long i = 0; i < n; ++i) {
            if (serial[i] != parallel[i]) { match = 0; break; }
        }

        if (serial_time > 0.0 && elapsed > 0.0)
            printf("| %7d | %16.6f | %8.4f | %-11s |\n",
                   threads, elapsed, serial_time / elapsed, match ? "yes" : "no");
        else
            printf("| %7d | %16.6f | %8s | %-11s |\n",
                   threads, elapsed, "N/A", match ? "yes" : "no");
    }
    printf("+---------+------------------+----------+-------------+\n");
    free(a); free(b); free(serial); free(parallel);
}

int main(void) {
    run_case(100000);
    run_case(1000000);
    run_case(10000000);
    run_case(100000000);
    return 0;
}
