@echo off
setlocal
cd /d "%~dp0"

where gcc >nul 2>nul
if errorlevel 1 (
    echo ERROR: GCC was not found. Install GCC with OpenMP support and add it to PATH.
    pause
    exit /b 1
)

echo Compiling all CS527 OpenMP tasks...
gcc -std=c11 -O2 -fopenmp -Wall Task1_VectorAddition.c -o task1.exe
if errorlevel 1 goto compile_error
gcc -std=c11 -O2 -fopenmp -Wall Task2_ArraySum.c -o task2.exe
if errorlevel 1 goto compile_error
gcc -std=c11 -O2 -fopenmp -Wall Task3_ArrayMinMax.c -o task3.exe
if errorlevel 1 goto compile_error
gcc -std=c11 -O2 -fopenmp -Wall Task4_MatrixAddition.c -o task4.exe
if errorlevel 1 goto compile_error
gcc -std=c11 -O2 -fopenmp -Wall Task5_MatrixMultiplication.c -o task5.exe
if errorlevel 1 goto compile_error

:menu
cls
echo ============================================================
echo                 CS527 OPENMP LAB MENU
echo ============================================================
echo 1. Task 1 - Vector Addition
echo 2. Task 2 - Array Sum
echo 3. Task 3 - Array Min/Max
echo 4. Task 4 - Matrix Addition
echo 5. Task 5 - Matrix Multiplication
echo 0. Exit
echo ============================================================
set "choice="
set /p "choice=Choose a task (0-5): "

if "%choice%"=="1" goto task1
if "%choice%"=="2" goto task2
if "%choice%"=="3" goto task3
if "%choice%"=="4" goto task4
if "%choice%"=="5" goto task5
if "%choice%"=="0" goto exit_program
echo Invalid choice. Enter a number from 0 to 5.
pause
goto menu

:task1
echo.
task1.exe
pause
goto menu

:task2
echo.
task2.exe
pause
goto menu

:task3
echo.
task3.exe
pause
goto menu

:task4
echo.
task4.exe
pause
goto menu

:task5
echo.
task5.exe
pause
goto menu

:compile_error
echo.
echo Compilation failed. Check the compiler errors above.
pause
exit /b 1

:exit_program
echo Exiting.
endlocal
exit /b 0
