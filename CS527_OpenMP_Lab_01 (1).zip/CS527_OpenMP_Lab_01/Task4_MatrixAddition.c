#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

static void run_case(int n) {
    size_t count = (size_t)n * n;
    int *a = malloc(count * sizeof(int));
    int *b = malloc(count * sizeof(int));
    int *serial = malloc(count * sizeof(int));
    int *outer = malloc(count * sizeof(int));
    int *collapse = malloc(count * sizeof(int));
    if (!a || !b || !serial || !outer || !collapse) {
        printf("Memory allocation failed for N=%d\n", n);
        free(a); free(b); free(serial); free(outer); free(collapse);
        return;
    }

    for (size_t i = 0; i < count; ++i) {
        a[i] = (int)(i % 100);
        b[i] = (int)((i * 7) % 100);
    }

    double start = omp_get_wtime();
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
            serial[(size_t)i * n + j] = a[(size_t)i * n + j] + b[(size_t)i * n + j];
    double serial_time = omp_get_wtime() - start;

    printf("\nTASK 4: MATRIX ADDITION | Matrix=%d x %d | Serial time=%.6f s\n", n, n, serial_time);
    printf("+---------+------------------+----------------+------------------+----------------+\n");
    printf("| Threads | Outer Time (s)   | Outer Match    | Collapse Time(s) | Collapse Match |\n");
    printf("+---------+------------------+----------------+------------------+----------------+\n");

    int thread_counts[] = {1, 2, 4, 8};
    for (int t = 0; t < 4; ++t) {
        int threads = thread_counts[t];
        start = omp_get_wtime();
        #pragma omp parallel for num_threads(threads)
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < n; ++j)
                outer[(size_t)i * n + j] = a[(size_t)i * n + j] + b[(size_t)i * n + j];
        double outer_time = omp_get_wtime() - start;

        start = omp_get_wtime();
        #pragma omp parallel for collapse(2) num_threads(threads)
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < n; ++j)
                collapse[(size_t)i * n + j] = a[(size_t)i * n + j] + b[(size_t)i * n + j];
        double collapse_time = omp_get_wtime() - start;

        int match_outer = 1, match_collapse = 1;
        for (size_t i = 0; i < count; ++i) {
            if (serial[i] != outer[i]) match_outer = 0;
            if (serial[i] != collapse[i]) match_collapse = 0;
        }
        printf("| %7d | %16.6f | %-14s | %16.6f | %-14s |\n",
               threads, outer_time, match_outer ? "yes" : "no",
               collapse_time, match_collapse ? "yes" : "no");
    }
    printf("+---------+------------------+----------------+------------------+----------------+\n");
    free(a); free(b); free(serial); free(outer); free(collapse);
}

int main(void) {
    run_case(8);
    run_case(4096);
    return 0;
}
