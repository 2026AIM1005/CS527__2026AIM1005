# CS527 OpenMP Lab Solutions (C) — Tabular Output Edition

## Included tasks
1. Vector addition
2. Array sum (includes an intentionally broken data-race demonstration)
3. Array maximum/minimum and indices
4. Matrix addition (outer loop and `collapse(2)`)
5. Matrix multiplication (outer loop and `collapse(2)`)

All programs print results in console tables for easier reading.

## Windows run instructions
1. Extract this ZIP.
2. Open the extracted folder.
3. Run:
   ```powershell
   .\run_all.bat
   ```
4. The wrapper compiles all five C programs and shows a menu.
5. Enter `1`–`5` to run a task. After it finishes, press a key to return to the menu.
6. Enter `0` to exit.

## Requirements
GCC with OpenMP support must be installed and added to PATH. MSYS2 MinGW-w64 GCC is suitable.

## Notes
- Some tasks allocate large arrays or matrices and may need significant RAM.
- Task 2 intentionally demonstrates an unsafe shared sum with a data race; its result can vary between runs.
- Timing results vary by computer and system load. Repeat timings before making performance claims.
- Very short timings may display as 0.000000 seconds because of timer resolution.
