#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

static int *allocate_matrix(int n) {
    return malloc((size_t)n * n * sizeof(int));
}

static void run_case(int n) {
    int *a = allocate_matrix(n);
    int *b = allocate_matrix(n);
    int *serial = allocate_matrix(n);
    int *outer = allocate_matrix(n);
    int *collapse = allocate_matrix(n);
    if (!a || !b || !serial || !outer || !collapse) {
        printf("Memory allocation failed for N=%d\n", n);
        free(a); free(b); free(serial); free(outer); free(collapse);
        return;
    }

    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            a[(size_t)i * n + j] = (i + j) % 10;
            b[(size_t)i * n + j] = (i * 2 + j) % 10;
        }
    }

    double start = omp_get_wtime();
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            int sum = 0;
            for (int k = 0; k < n; ++k)
                sum += a[(size_t)i * n + k] * b[(size_t)k * n + j];
            serial[(size_t)i * n + j] = sum;
        }
    }
    double serial_time = omp_get_wtime() - start;

    printf("\nTASK 5: MATRIX MULTIPLICATION | Matrix=%d x %d | Serial time=%.6f s\n", n, n, serial_time);
    printf("+---------+------------------+----------+------------+------------------+----------+------------+----------------+\n");
    printf("| Threads | Outer Time (s)   | Speedup  | Efficiency | Collapse Time(s) | Speedup  | Efficiency | Both Match     |\n");
    printf("+---------+------------------+----------+------------+------------------+----------+------------+----------------+\n");

    int thread_counts[] = {1, 2, 4, 8};
    for (int t = 0; t < 4; ++t) {
        int threads = thread_counts[t];

        start = omp_get_wtime();
        #pragma omp parallel for num_threads(threads)
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                int sum = 0;
                for (int k = 0; k < n; ++k)
                    sum += a[(size_t)i * n + k] * b[(size_t)k * n + j];
                outer[(size_t)i * n + j] = sum;
            }
        }
        double outer_time = omp_get_wtime() - start;

        start = omp_get_wtime();
        #pragma omp parallel for collapse(2) num_threads(threads)
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                int sum = 0;
                for (int k = 0; k < n; ++k)
                    sum += a[(size_t)i * n + k] * b[(size_t)k * n + j];
                collapse[(size_t)i * n + j] = sum;
            }
        }
        double collapse_time = omp_get_wtime() - start;

        int match_outer = 1, match_collapse = 1;
        size_t count = (size_t)n * n;
        for (size_t i = 0; i < count; ++i) {
            if (serial[i] != outer[i]) match_outer = 0;
            if (serial[i] != collapse[i]) match_collapse = 0;
        }

        double outer_speedup = outer_time > 0.0 ? serial_time / outer_time : 0.0;
        double collapse_speedup = collapse_time > 0.0 ? serial_time / collapse_time : 0.0;
        printf("| %7d | %16.6f | %8.3f | %10.3f | %16.6f | %8.3f | %10.3f | %-14s |\n",
               threads, outer_time, outer_speedup, outer_speedup / threads,
               collapse_time, collapse_speedup, collapse_speedup / threads,
               match_outer && match_collapse ? "yes" : "no");
    }
    printf("+---------+------------------+----------+------------+------------------+----------+------------+----------------+\n");
    free(a); free(b); free(serial); free(outer); free(collapse);
}

int main(void) {
    run_case(256);
    run_case(512);
    run_case(1024);
    return 0;
}
