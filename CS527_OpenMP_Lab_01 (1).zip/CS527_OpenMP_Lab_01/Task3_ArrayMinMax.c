#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <omp.h>

static void run_case(long long n) {
    int *a = malloc((size_t)n * sizeof(int));
    if (!a) {
        printf("Memory allocation failed for N=%lld\n", n);
        return;
    }

    for (long long i = 0; i < n; ++i) a[i] = (int)((i % 5) - 2);
    a[n / 3] = 2000000;
    a[n / 2] = -2000000;

    int serial_max = INT_MIN, serial_min = INT_MAX;
    long long max_index = -1, min_index = -1;
    double start = omp_get_wtime();
    for (long long i = 0; i < n; ++i) {
        if (a[i] > serial_max) { serial_max = a[i]; max_index = i; }
        if (a[i] < serial_min) { serial_min = a[i]; min_index = i; }
    }
    double serial_time = omp_get_wtime() - start;

    int local_max = INT_MIN, local_min = INT_MAX;
    start = omp_get_wtime();
    #pragma omp parallel for reduction(max:local_max) reduction(min:local_min)
    for (long long i = 0; i < n; ++i) {
        if (a[i] > local_max) local_max = a[i];
        if (a[i] < local_min) local_min = a[i];
    }
    double reduction_time = omp_get_wtime() - start;

    int critical_max = INT_MIN, critical_min = INT_MAX;
    long long critical_max_index = -1, critical_min_index = -1;
    start = omp_get_wtime();
    #pragma omp parallel for num_threads(4)
    for (long long i = 0; i < n; ++i) {
        #pragma omp critical
        {
            if (a[i] > critical_max) {
                critical_max = a[i];
                critical_max_index = i;
            }
            if (a[i] < critical_min) {
                critical_min = a[i];
                critical_min_index = i;
            }
        }
    }
    double critical_time = omp_get_wtime() - start;

    printf("\nTASK 3: ARRAY MIN/MAX | N=%lld | Serial time=%.6f s\n", n, serial_time);
    printf("+---------+-----------+------------------+------------------+--------------------+\n");
    printf("| Result  | Value     | Index            | Reduction Match  | Critical Pair Match|\n");
    printf("+---------+-----------+------------------+------------------+--------------------+\n");
    printf("| Maximum | %9d | %16lld | %-16s | %-18s |\n",
           serial_max, max_index, local_max == serial_max ? "yes" : "no",
           critical_max == serial_max && critical_max_index == max_index ? "yes" : "no");
    printf("| Minimum | %9d | %16lld | %-16s | %-18s |\n",
           serial_min, min_index, local_min == serial_min ? "yes" : "no",
           critical_min == serial_min && critical_min_index == min_index ? "yes" : "no");
    printf("+---------+-----------+------------------+------------------+--------------------+\n");
    printf("\n+----------------------+------------------+\n");
    printf("| Method               | Time (s)         |\n");
    printf("+----------------------+------------------+\n");
    printf("| Value reduction      | %16.6f |\n", reduction_time);
    printf("| Critical pair (4T)   | %16.6f |\n", critical_time);
    printf("+----------------------+------------------+\n");

    free(a);
}

int main(void) {
    run_case(10000000);
    run_case(100000000);
    return 0;
}
