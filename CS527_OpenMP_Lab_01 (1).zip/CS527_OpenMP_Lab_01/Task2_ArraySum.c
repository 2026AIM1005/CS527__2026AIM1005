#include <stdio.h>
#include <stdlib.h>
#include <omp.h>

static void run_case(long long n) {
    long long *a = malloc((size_t)n * sizeof(long long));
    if (!a) {
        printf("Memory allocation failed for N=%lld\n", n);
        return;
    }
    for (long long i = 0; i < n; ++i) a[i] = 1;

    long long expected = n, serial_sum = 0;
    double start = omp_get_wtime();
    for (long long i = 0; i < n; ++i) serial_sum += a[i];
    double serial_time = omp_get_wtime() - start;

    printf("\nTASK 2: ARRAY SUM | N=%lld | Expected=%lld | Serial time=%.6f s | Serial match=%s\n",
           n, expected, serial_time, serial_sum == expected ? "yes" : "no");

    printf("\nBroken parallel sum (intentional data race):\n");
    printf("+-----+------------------+----------------+\n");
    printf("| Run | Calculated Sum   | Correct?       |\n");
    printf("+-----+------------------+----------------+\n");
    for (int r = 1; r <= 3; ++r) {
        long long sum = 0;
        #pragma omp parallel for shared(sum)
        for (long long i = 0; i < n; ++i) sum += a[i];
        printf("| %3d | %16lld | %-14s |\n", r, sum, sum == expected ? "yes" : "no");
    }
    printf("+-----+------------------+----------------+\n");

    printf("\nOpenMP reduction:\n");
    printf("+---------+------------------+----------------+\n");
    printf("| Threads | Time (s)         | Match          |\n");
    printf("+---------+------------------+----------------+\n");
    int thread_counts[] = {1, 2, 4, 8};
    for (int t = 0; t < 4; ++t) {
        int threads = thread_counts[t];
        long long sum = 0;
        start = omp_get_wtime();
        #pragma omp parallel for num_threads(threads) reduction(+:sum)
        for (long long i = 0; i < n; ++i) sum += a[i];
        double elapsed = omp_get_wtime() - start;
        printf("| %7d | %16.6f | %-14s |\n", threads, elapsed, sum == expected ? "yes" : "no");
    }
    printf("+---------+------------------+----------------+\n");

    if (n <= 10000000) {
        long long critical_sum = 0;
        start = omp_get_wtime();
        #pragma omp parallel for num_threads(4)
        for (long long i = 0; i < n; ++i) {
            #pragma omp critical
            critical_sum += a[i];
        }
        double elapsed = omp_get_wtime() - start;
        printf("\nCritical-section method:\n");
        printf("+---------+------------------+----------------+\n");
        printf("| Threads | Time (s)         | Match          |\n");
        printf("+---------+------------------+----------------+\n");
        printf("| %7d | %16.6f | %-14s |\n", 4, elapsed, critical_sum == expected ? "yes" : "no");
        printf("+---------+------------------+----------------+\n");
    }
    free(a);
}

int main(void) {
    run_case(10000000);
    run_case(100000000);
    return 0;
}
