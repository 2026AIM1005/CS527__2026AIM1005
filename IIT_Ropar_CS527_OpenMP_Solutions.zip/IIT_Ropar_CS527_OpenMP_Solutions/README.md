# IIT Ropar M.Tech CS527 – OpenMP Coding Solutions

This package contains **30 standalone C programs** covering the major OpenMP lab-test patterns from the 125-question preparation bank: parallel regions, loop work-sharing, array/matrix operations, reductions, atomic/critical/locks, scheduling, sections/single/barrier, tasks, sorting, prefix sum, numerical methods, sparse matrix operations, graph traversal, performance and debugging.

These are practice solutions, not an official IIT Ropar question paper or a guarantee of exam questions. Several related questions in the question bank are covered by one reusable program (for example, array sum/min/max/even-odd are combined in `02_array_reductions.c`).

## 1. Requirements

- GCC compiler with OpenMP support.
- Linux: GCC is usually available through the package manager.
- Windows: use MSYS2 MinGW-w64 GCC, or another GCC distribution built with OpenMP.
- A terminal opened in this folder.

Check the compiler:

```bash
gcc --version
gcc -fopenmp -dM -E - < /dev/null | grep OPENMP
```

The second command is for Linux/MSYS2 Bash. If it prints `_OPENMP`, compiler OpenMP support is enabled.

## 2. Compile and run

### Linux / MSYS2 Bash

From the `solutions` directory:

```bash
gcc -O2 -std=c11 -Wall -Wextra -fopenmp 02_array_reductions.c -o program
./program
```

General pattern:

```bash
gcc -O2 -std=c11 -Wall -Wextra -fopenmp FILE.c -o program
./program
```

### Windows PowerShell (GCC available on PATH)

```powershell
gcc -O2 -std=c11 -Wall -Wextra -fopenmp .\02_array_reductions.c -o .\program.exe
.\program.exe
```

General pattern:

```powershell
gcc -O2 -std=c11 -Wall -Wextra -fopenmp .\FILE.c -o .\program.exe
.\program.exe
```

Set the default thread count:

Linux / Bash:
```bash
export OMP_NUM_THREADS=4
./program
```

PowerShell:
```powershell
$env:OMP_NUM_THREADS = "4"
.\program.exe
```

Some examples explicitly set the thread count in code; that setting takes precedence for those regions.

## 3. Compile all programs

### Linux / MSYS2 Bash

Run from the project root:

```bash
mkdir -p bin
for f in solutions/*.c; do
    name=$(basename "$f" .c)
    gcc -O2 -std=c11 -Wall -Wextra -fopenmp "$f" -lm -o "bin/$name" || exit 1
done
```

Run an example:

```bash
./bin/02_array_reductions
```

### Windows PowerShell

Run from the project root:

```powershell
New-Item -ItemType Directory -Force bin | Out-Null
Get-ChildItem .\solutions\*.c | ForEach-Object {
    $name = $_.BaseName
    gcc -O2 -std=c11 -Wall -Wextra -fopenmp $_.FullName -lm -o ".\bin\$name.exe"
    if ($LASTEXITCODE -ne 0) { throw "Compilation failed: $($_.Name)" }
}
```

Run an example:

```powershell
.\bin\02_array_reductions.exe
```

## 4. Program index

| File | Topics / questions covered |
|---|---|
| `01_hello_threads.c` | Hello World, thread IDs, team size |
| `02_array_reductions.c` | Sum, min, max, average, even/odd, positive/negative/zero |
| `03_vector_operations.c` | Vector add/subtract/multiply, dot product |
| `04_matrix_operations.c` | Matrix addition, transpose, multiplication |
| `05_matrix_multiply_timing.c` | Serial vs parallel matrix multiplication, collapse, verification |
| `06_reduction_atomic_critical.c` | Sum with reduction, atomic, critical; timing comparison |
| `07_histogram_three_methods.c` | Histogram with atomic, critical, thread-private arrays |
| `08_scheduling_comparison.c` | Static, dynamic, guided scheduling on uneven work |
| `09_thread_iteration_mapping.c` | Thread-to-iteration mapping and chunk size |
| `10_sections_single_barrier.c` | Sections, single, master, barrier |
| `11_task_fibonacci.c` | Recursive Fibonacci tasks and cutoff |
| `12_task_merge_sort.c` | Task-based merge sort, taskwait, cutoff |
| `13_task_quicksort.c` | Task-based quicksort |
| `14_odd_even_sort.c` | Odd-even transposition sort |
| `15_parallel_prefix_sum.c` | Inclusive prefix scan using doubling |
| `16_numerical_integration_pi.c` | Midpoint integration for pi, reduction |
| `17_monte_carlo_pi.c` | Monte Carlo pi estimation, thread-local random seeds |
| `18_producer_consumer_bounded_buffer.c` | Producer-consumer, bounded buffer, lock |
| `19_jacobi_1d.c` | Jacobi iterative stencil |
| `20_sparse_csr_spmv.c` | Sparse matrix-vector multiplication in CSR |
| `21_parallel_bfs.c` | Level-synchronous BFS with synchronized visited/queue updates |
| `22_prime_sieve.c` | Sieve of Eratosthenes with parallel marking and counting |
| `23_standard_deviation.c` | Mean and population standard deviation with reductions |
| `24_thread_private_firstprivate.c` | `private` vs `firstprivate` |
| `25_false_sharing_demo.c` | False-sharing experiment (timings hardware-dependent) |
| `26_mandelbrot.c` | Mandelbrot rendering with dynamic scheduling |
| `27_trapezoidal_rule.c` | Trapezoidal numerical integration |
| `28_lock_counter.c` | Explicit OpenMP lock and race-free counter |
| `29_task_sum_cutoff.c` | Divide-and-conquer task sum with cutoff |
| `30_amdahl_speedup.c` | Thread scaling, speedup, efficiency, result verification |

## 5. Important concepts to understand for viva

- `parallel`: creates a team of threads.
- `for`: distributes loop iterations among the current team.
- `parallel for`: combines parallel region and loop work-sharing.
- `collapse(2)`: combines two nested loops into one iteration space.
- `reduction(+:x)`: gives threads private partial values and combines them.
- `atomic`: makes a supported memory update atomic; it does not protect arbitrary multi-statement code.
- `critical`: only one thread at a time executes that named/unnamed critical region.
- `barrier`: all threads in the team must reach the barrier before any proceed.
- `single`: one team thread executes the block; there is an implicit barrier unless `nowait` is used.
- `sections`: distributes independent sections among team threads.
- `task`: creates a task that may execute on any eligible team thread.
- `taskwait`: waits for child tasks generated by the current task.
- `schedule(static)`: assigns chunks in a predetermined way.
- `schedule(dynamic)`: threads request more chunks as they finish.
- `schedule(guided)`: dynamically assigns progressively smaller chunks (subject to the minimum chunk size).

## 6. Common exam formulas

- Execution time: `T`
- Speedup: `S = T_serial / T_parallel`
- Efficiency: `E = S / number_of_threads`
- Parallel overhead is why speedup may be below the ideal thread count.
- A race condition occurs when concurrent accesses conflict and at least one access is a write, without appropriate synchronization.
- A reduction is generally preferable to repeatedly entering a critical section for a simple associative accumulation.

## 7. Important correctness notes

1. Parallel output order is not deterministic. Do not compare the order of thread print statements.
2. Timing depends on CPU, compiler, thread count, OS scheduling and problem size. Do not memorize sample timing values.
3. `17_monte_carlo_pi.c` uses a separate pseudo-random seed per thread; the estimate varies by implementation and run.
4. `18_producer_consumer_bounded_buffer.c` is a compact busy-wait teaching example. It demonstrates lock-protected buffer state, but production producer-consumer systems should use proper waiting/signalling primitives to avoid wasting CPU.
5. `21_parallel_bfs.c` uses critical sections for a simple correct small-graph demonstration; it is not a high-performance frontier implementation.
6. `25_false_sharing_demo.c` is illustrative; compiler optimizations and machine cache layout can affect results. Treat timings as observations, not guaranteed proof.
7. The prefix-sum program uses a Hillis–Steele-style doubling algorithm, which is simple and correct but performs O(n log n) work rather than the work-optimal O(n) scan.
8. The Jacobi example uses fixed iteration count, not a convergence tolerance.
9. The quicksort and merge-sort examples are demonstrations with small fixed arrays; increase input size and tune cutoffs for meaningful performance experiments.

## 8. Suggested lab-test practice order

1. `02_array_reductions.c`
2. `06_reduction_atomic_critical.c`
3. `07_histogram_three_methods.c`
4. `08_scheduling_comparison.c`
5. `04_matrix_operations.c` and `05_matrix_multiply_timing.c`
6. `12_task_merge_sort.c` and `13_task_quicksort.c`
7. `15_parallel_prefix_sum.c`
8. `18_producer_consumer_bounded_buffer.c`
9. `16_numerical_integration_pi.c` and `17_monte_carlo_pi.c`
10. Remaining advanced examples.

## 9. Troubleshooting

- `gcc is not recognized`: install/configure GCC and add its `bin` folder to PATH, or open the MSYS2 MinGW 64-bit terminal.
- `undefined reference to GOMP_*` or OpenMP symbols: compile and link with `-fopenmp`.
- `undefined reference to sqrt`: add `-lm` at the end of the GCC command.
- `rand_r` warning on some Windows toolchains: use the MSYS2 MinGW-w64 GCC toolchain; `rand_r` is POSIX and is not part of ISO C.
- If a program appears slower with more threads, try larger inputs and account for thread creation, synchronization and scheduling overhead.

Good luck with your CS527 OpenMP lab test!
