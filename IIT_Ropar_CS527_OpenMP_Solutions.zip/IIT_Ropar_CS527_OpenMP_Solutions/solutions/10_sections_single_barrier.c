#include <stdio.h>
#include <omp.h>
int main(void) {
    #pragma omp parallel num_threads(4)
    {
        #pragma omp sections
        {
            #pragma omp section
            printf("Section A by thread %d\n",omp_get_thread_num());
            #pragma omp section
            printf("Section B by thread %d\n",omp_get_thread_num());
            #pragma omp section
            printf("Section C by thread %d\n",omp_get_thread_num());
        }
        #pragma omp single
        printf("Single executed by thread %d\n",omp_get_thread_num());
        #pragma omp barrier
        #pragma omp master
        printf("Master executed by thread %d\n",omp_get_thread_num());
    }
    return 0;
}
