#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#define N 100000
#define BINS 10
int main(void) {
    static int a[N], h1[BINS]={0}, h2[BINS]={0};
    for(int i=0;i<N;i++) a[i]=(i*17+i/7)%BINS;
    #pragma omp parallel for
    for(int i=0;i<N;i++){
        #pragma omp atomic update
        h1[a[i]]++;
    }
    #pragma omp parallel for
    for(int i=0;i<N;i++){
        #pragma omp critical
        h2[a[i]]++;
    }
    int nt=omp_get_max_threads();
    int *local=calloc((size_t)nt*BINS,sizeof(int));
    #pragma omp parallel
    {
        int tid=omp_get_thread_num();
        #pragma omp for
        for(int i=0;i<N;i++) local[tid*BINS+a[i]]++;
    }
    int h3[BINS]={0};
    for(int t=0;t<nt;t++) for(int b=0;b<BINS;b++) h3[b]+=local[t*BINS+b];
    for(int b=0;b<BINS;b++)
        printf("bin %d: atomic=%d critical=%d private=%d %s\n",
               b,h1[b],h2[b],h3[b],(h1[b]==h2[b]&&h2[b]==h3[b])?"PASS":"FAIL");
    free(local);
    return 0;
}
