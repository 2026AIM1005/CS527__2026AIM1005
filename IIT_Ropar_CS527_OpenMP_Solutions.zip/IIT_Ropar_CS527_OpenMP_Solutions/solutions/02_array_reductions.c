#include <stdio.h>
#include <omp.h>
int main(void) {
    int a[] = {10, 25, 5, 40, 15, 2, 50, -3};
    int n = sizeof(a) / sizeof(a[0]);
    long long sum = 0;
    int mn = a[0], mx = a[0], even = 0, odd = 0, positive = 0, negative = 0, zero = 0;
    #pragma omp parallel for reduction(+:sum,even,odd,positive,negative,zero) reduction(min:mn) reduction(max:mx)
    for (int i = 0; i < n; ++i) {
        sum += a[i];
        if (a[i] % 2 == 0) even++; else odd++;
        if (a[i] > 0) positive++; else if (a[i] < 0) negative++; else zero++;
        if (a[i] < mn) mn = a[i];
        if (a[i] > mx) mx = a[i];
    }
    printf("sum=%lld min=%d max=%d even=%d odd=%d positive=%d negative=%d zero=%d average=%.2f\n",
           sum, mn, mx, even, odd, positive, negative, zero, (double)sum/n);
    return 0;
}
