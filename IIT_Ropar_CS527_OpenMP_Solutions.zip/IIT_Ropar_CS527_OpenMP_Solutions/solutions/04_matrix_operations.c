#include <stdio.h>
#include <omp.h>
#define N 3
int main(void) {
    int a[N][N]={{1,2,3},{4,5,6},{7,8,9}};
    int b[N][N]={{9,8,7},{6,5,4},{3,2,1}};
    int add[N][N], trans[N][N], product[N][N]={{0}};
    #pragma omp parallel for collapse(2)
    for (int i=0;i<N;i++) for (int j=0;j<N;j++) {
        add[i][j]=a[i][j]+b[i][j];
        trans[j][i]=a[i][j];
    }
    #pragma omp parallel for collapse(2)
    for (int i=0;i<N;i++) for (int j=0;j<N;j++) {
        int s=0;
        for (int k=0;k<N;k++) s += a[i][k]*b[k][j];
        product[i][j]=s;
    }
    printf("A+B:\n");
    for(int i=0;i<N;i++){for(int j=0;j<N;j++)printf("%d ",add[i][j]);puts("");}
    printf("Transpose(A):\n");
    for(int i=0;i<N;i++){for(int j=0;j<N;j++)printf("%d ",trans[i][j]);puts("");}
    printf("A*B:\n");
    for(int i=0;i<N;i++){for(int j=0;j<N;j++)printf("%d ",product[i][j]);puts("");}
    return 0;
}
