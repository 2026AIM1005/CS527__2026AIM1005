#include <stdio.h>
#include <omp.h>
long long fib_serial(int n){return n<2?n:fib_serial(n-1)+fib_serial(n-2);}
long long fib_task(int n,int cutoff){
    if(n<2) return n;
    if(n<=cutoff) return fib_serial(n);
    long long x=0,y=0;
    #pragma omp task shared(x) firstprivate(n,cutoff)
    x=fib_task(n-1,cutoff);
    #pragma omp task shared(y) firstprivate(n,cutoff)
    y=fib_task(n-2,cutoff);
    #pragma omp taskwait
    return x+y;
}
int main(void){
    int n=35;
    long long result=0;
    #pragma omp parallel
    #pragma omp single
    result=fib_task(n,20);
    printf("fib(%d)=%lld\n",n,result);
    return 0;
}
