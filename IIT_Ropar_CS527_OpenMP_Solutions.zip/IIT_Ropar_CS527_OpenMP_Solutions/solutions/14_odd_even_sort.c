#include <stdio.h>
#define N 10
int main(void){
    int a[N]={9,4,7,3,10,1,8,2,6,5};
    for(int phase=0;phase<N;phase++){
        int start=phase%2;
        #pragma omp parallel for
        for(int i=start;i<N-1;i+=2)
            if(a[i]>a[i+1]){int t=a[i];a[i]=a[i+1];a[i+1]=t;}
    }
    for(int i=0;i<N;i++)printf("%d ",a[i]);
    puts("");
    return 0;
}
