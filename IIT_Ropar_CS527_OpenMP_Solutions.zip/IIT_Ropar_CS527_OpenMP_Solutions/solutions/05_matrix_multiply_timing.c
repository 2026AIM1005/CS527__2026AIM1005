#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#define N 300
int main(void) {
    static double a[N][N], b[N][N], serial[N][N], parallel[N][N];
    for(int i=0;i<N;i++) for(int j=0;j<N;j++){a[i][j]=(i+j)%7; b[i][j]=(i*2+j)%5;}
    double t=omp_get_wtime();
    for(int i=0;i<N;i++) for(int j=0;j<N;j++){
        double s=0; for(int k=0;k<N;k++) s+=a[i][k]*b[k][j]; serial[i][j]=s;
    }
    double ts=omp_get_wtime()-t;
    t=omp_get_wtime();
    #pragma omp parallel for collapse(2) schedule(static)
    for(int i=0;i<N;i++) for(int j=0;j<N;j++){
        double s=0; for(int k=0;k<N;k++) s+=a[i][k]*b[k][j]; parallel[i][j]=s;
    }
    double tp=omp_get_wtime()-t;
    int ok=1;
    for(int i=0;i<N;i++) for(int j=0;j<N;j++)
        if(abs((int)(serial[i][j]-parallel[i][j]))>0) ok=0;
    printf("N=%d serial=%.6f s parallel=%.6f s speedup=%.3f verification=%s\n",
           N,ts,tp,ts/tp,ok?"PASS":"FAIL");
    return 0;
}
