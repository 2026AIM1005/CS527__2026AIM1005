#include <stdio.h>
#include <omp.h>
double f(double x){return x*x;}
int main(void){
    double a=0,b=1;long long n=10000000;
    double h=(b-a)/n,sum=(f(a)+f(b))/2.0;
    double t=omp_get_wtime();
    #pragma omp parallel for reduction(+:sum)
    for(long long i=1;i<n;i++)sum+=f(a+i*h);
    printf("integral=%.10f time=%.6f s\n",sum*h,omp_get_wtime()-t);
    return 0;
}
