#include <stdio.h>
#include <omp.h>
#define N 16
static double work(int i) {
    double x=0;
    for(int k=0;k<(i+1)*20000;k++) x += (k%17)*0.00001;
    return x;
}
int main(void) {
    double total=0, t;
    t=omp_get_wtime();
    #pragma omp parallel for schedule(static) reduction(+:total)
    for(int i=0;i<N;i++) total+=work(i);
    printf("static:  total=%.4f time=%.6f\n",total,omp_get_wtime()-t);
    total=0; t=omp_get_wtime();
    #pragma omp parallel for schedule(dynamic,1) reduction(+:total)
    for(int i=0;i<N;i++) total+=work(i);
    printf("dynamic: total=%.4f time=%.6f\n",total,omp_get_wtime()-t);
    total=0; t=omp_get_wtime();
    #pragma omp parallel for schedule(guided,1) reduction(+:total)
    for(int i=0;i<N;i++) total+=work(i);
    printf("guided:  total=%.4f time=%.6f\n",total,omp_get_wtime()-t);
    return 0;
}
