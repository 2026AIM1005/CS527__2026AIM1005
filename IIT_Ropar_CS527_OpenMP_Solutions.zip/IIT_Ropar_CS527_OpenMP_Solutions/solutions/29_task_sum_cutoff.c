#include <stdio.h>
#include <omp.h>
#define N 1000000
#define CUTOFF 10000
long long sum_range(int l,int r){
    if(r-l<=CUTOFF){long long s=0;for(int i=l;i<r;i++)s+=i;return s;}
    int m=l+(r-l)/2;long long x=0,y=0;
    #pragma omp task shared(x) firstprivate(l,m)
    x=sum_range(l,m);
    #pragma omp task shared(y) firstprivate(m,r)
    y=sum_range(m,r);
    #pragma omp taskwait
    return x+y;
}
int main(void){
    long long ans=0;
    #pragma omp parallel
    #pragma omp single
    ans=sum_range(1,N+1);
    printf("sum 1..%d = %lld\n",N,ans);
    return 0;
}
