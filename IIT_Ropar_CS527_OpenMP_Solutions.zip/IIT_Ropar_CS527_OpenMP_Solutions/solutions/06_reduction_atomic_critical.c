#include <stdio.h>
#include <omp.h>
#define N 1000000
int main(void) {
    static int a[N];
    for(int i=0;i<N;i++) a[i]=1;
    long long sum=0; double t=omp_get_wtime();
    #pragma omp parallel for reduction(+:sum)
    for(int i=0;i<N;i++) sum+=a[i];
    double tr=omp_get_wtime()-t;
    long long atomic_sum=0; t=omp_get_wtime();
    #pragma omp parallel for
    for(int i=0;i<N;i++){
        #pragma omp atomic update
        atomic_sum+=a[i];
    }
    double ta=omp_get_wtime()-t;
    long long critical_sum=0; t=omp_get_wtime();
    #pragma omp parallel for
    for(int i=0;i<N;i++){
        #pragma omp critical
        critical_sum+=a[i];
    }
    double tc=omp_get_wtime()-t;
    printf("expected=%d\nreduction=%lld time=%.6f\natomic=%lld time=%.6f\ncritical=%lld time=%.6f\n",
           N,sum,tr,atomic_sum,ta,critical_sum,tc);
    return !(sum==N && atomic_sum==N && critical_sum==N);
}
