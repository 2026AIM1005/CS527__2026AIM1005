#include <stdio.h>
#include <omp.h>
int main(void){
    /* Matrix [[10,0,0],[0,20,30],[0,0,40]] in CSR */
    int rowptr[]={0,1,3,4}, col[]={0,1,2,2}, val[]={10,20,30,40};
    double x[]={1,2,3}, y[3]={0};
    #pragma omp parallel for
    for(int r=0;r<3;r++){
        double s=0;
        for(int k=rowptr[r];k<rowptr[r+1];k++)s+=val[k]*x[col[k]];
        y[r]=s;
    }
    for(int r=0;r<3;r++)printf("y[%d]=%.1f\n",r,y[r]);
    return 0;
}
