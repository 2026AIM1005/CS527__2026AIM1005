#include <stdio.h>
#define N 20
#define CUTOFF 64
void quick(int a[],int l,int r){
    if(l>=r)return;
    if(r-l+1<=CUTOFF){
        for(int i=l+1;i<=r;i++){int x=a[i],j=i-1;while(j>=l&&a[j]>x){a[j+1]=a[j];j--;}a[j+1]=x;}
        return;
    }
    int p=a[r],i=l-1;
    for(int j=l;j<r;j++)if(a[j]<=p){i++;int t=a[i];a[i]=a[j];a[j]=t;}
    int t=a[i+1];a[i+1]=a[r];a[r]=t;
    int q=i+1;
    #pragma omp task shared(a) firstprivate(l,q)
    quick(a,l,q-1);
    #pragma omp task shared(a) firstprivate(q,r)
    quick(a,q+1,r);
    #pragma omp taskwait
}
int main(void){
    int a[N]={19,4,12,7,2,18,1,15,9,3,14,6,20,8,5,17,11,10,16,13};
    #pragma omp parallel
    #pragma omp single
    quick(a,0,N-1);
    for(int i=0;i<N;i++)printf("%d ",a[i]);
    puts("");
    return 0;
}
