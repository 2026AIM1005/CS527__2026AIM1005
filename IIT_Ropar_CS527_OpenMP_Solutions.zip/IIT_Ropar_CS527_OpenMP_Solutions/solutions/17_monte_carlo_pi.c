#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
int main(void){
    const long long samples=2000000;
    long long inside=0;
    #pragma omp parallel reduction(+:inside)
    {
        unsigned int seed=1234u+(unsigned int)omp_get_thread_num()*7919u;
        #pragma omp for
        for(long long i=0;i<samples;i++){
            double x=rand_r(&seed)/(double)RAND_MAX;
            double y=rand_r(&seed)/(double)RAND_MAX;
            if(x*x+y*y<=1.0)inside++;
        }
    }
    printf("estimated pi=%.8f (samples=%lld)\n",4.0*(double)inside/samples,samples);
    return 0;
}
