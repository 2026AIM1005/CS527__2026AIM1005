#include <stdio.h>
#include <omp.h>
int main(void){
    int x=10;
    #pragma omp parallel num_threads(4) private(x)
    {
        x=omp_get_thread_num();
        printf("private x=%d in thread %d\n",x,omp_get_thread_num());
    }
    #pragma omp parallel num_threads(4) firstprivate(x)
    {
        x+=omp_get_thread_num();
        printf("firstprivate x=%d in thread %d\n",x,omp_get_thread_num());
    }
    printf("original x=%d\n",x);
    return 0;
}
