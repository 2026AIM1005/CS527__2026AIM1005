#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
int main(void){
    int n=16, a[16], out[16];
    for(int i=0;i<n;i++)a[i]=i+1;
    int *tmp=malloc((size_t)n*sizeof(int));
    for(int i=0;i<n;i++)out[i]=a[i];
    for(int offset=1;offset<n;offset*=2){
        #pragma omp parallel for
        for(int i=0;i<n;i++){
            tmp[i]=out[i];
            if(i>=offset)tmp[i]+=out[i-offset];
        }
        #pragma omp parallel for
        for(int i=0;i<n;i++)out[i]=tmp[i];
    }
    printf("Inclusive prefix sum: ");
    for(int i=0;i<n;i++)printf("%d ",out[i]);
    puts("");
    free(tmp);
    return 0;
}
