#include <stdio.h>
#include <omp.h>
#define W 80
#define H 40
#define MAX_ITER 1000
int main(void){
    int image[H][W];
    #pragma omp parallel for schedule(dynamic,1)
    for(int y=0;y<H;y++)for(int x=0;x<W;x++){
        double cr=(x-W/2.0)*4.0/W, ci=(y-H/2.0)*4.0/W;
        double zr=0,zi=0;int it=0;
        while(zr*zr+zi*zi<=4.0 && it<MAX_ITER){
            double nr=zr*zr-zi*zi+cr;zi=2*zr*zi+ci;zr=nr;it++;
        }
        image[y][x]=it;
    }
    for(int y=0;y<H;y++){
        for(int x=0;x<W;x++)putchar(image[y][x]==MAX_ITER?'#':image[y][x]>30?'+':image[y][x]>10?'.':' ');
        putchar('\n');
    }
    return 0;
}
