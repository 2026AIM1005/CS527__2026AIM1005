#include <stdio.h>
#include <omp.h>
#define V 6
int main(void){
    int g[V][V]={{0,1,1,0,0,0},{1,0,0,1,1,0},{1,0,0,0,0,1},
                 {0,1,0,0,0,0},{0,1,0,0,0,1},{0,0,1,0,1,0}};
    int visited[V]={0},front[V],next[V],nf=0;
    front[nf++]=0;visited[0]=1;
    printf("BFS order: 0 ");
    while(nf){
        int nn=0;
        #pragma omp parallel for
        for(int i=0;i<nf;i++){
            int u=front[i];
            for(int v=0;v<V;v++)if(g[u][v]){
                int claim=0;
                #pragma omp critical
                {if(!visited[v]){visited[v]=1;claim=1;}}
                if(claim){
                    #pragma omp critical
                    {next[nn++]=v;}
                }
            }
        }
        for(int i=0;i<nn;i++)printf("%d ",next[i]);
        for(int i=0;i<nn;i++)front[i]=next[i];
        nf=nn;
    }
    puts("");
    return 0;
}
