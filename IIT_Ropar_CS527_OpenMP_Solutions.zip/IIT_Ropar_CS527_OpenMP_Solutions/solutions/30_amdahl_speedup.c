#include <stdio.h>
#include <omp.h>
int main(void){
    const long long n=100000000;
    double t=omp_get_wtime();long long s=0;
    for(long long i=0;i<n;i++)s+=i%7;
    double serial=omp_get_wtime()-t;
    for(int threads=1;threads<=8;threads*=2){
        long long p=0;t=omp_get_wtime();
        omp_set_num_threads(threads);
        #pragma omp parallel for reduction(+:p)
        for(long long i=0;i<n;i++)p+=i%7;
        double parallel=omp_get_wtime()-t;
        printf("threads=%d time=%.6f speedup=%.3f efficiency=%.3f verify=%s\n",
               threads,parallel,serial/parallel,(serial/parallel)/threads,p==s?"PASS":"FAIL");
    }
    return 0;
}
