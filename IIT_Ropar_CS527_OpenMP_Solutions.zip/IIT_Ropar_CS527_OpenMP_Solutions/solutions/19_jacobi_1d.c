#include <stdio.h>
#include <omp.h>
#define N 100
#define ITER 1000
int main(void){
    double aa[N+2]={0},bb[N+2]={0};
    double *a=aa,*b=bb;
    a[N+1]=b[N+1]=1.0;
    for(int it=0;it<ITER;it++){
        #pragma omp parallel for
        for(int i=1;i<=N;i++) b[i]=0.5*(a[i-1]+a[i+1]);
        double *p=a; a=b; b=p;
    }
    printf("middle value=%.8f after %d iterations\n",a[N/2],ITER);
    return 0;
}
