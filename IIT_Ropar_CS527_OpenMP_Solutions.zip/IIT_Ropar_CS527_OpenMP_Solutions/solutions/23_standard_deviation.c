#include <stdio.h>
#include <math.h>
#include <omp.h>
int main(void){
    double a[]={2,4,4,4,5,5,7,9};
    int n=sizeof(a)/sizeof(a[0]);
    double sum=0,sq=0;
    #pragma omp parallel for reduction(+:sum)
    for(int i=0;i<n;i++)sum+=a[i];
    double mean=sum/n;
    #pragma omp parallel for reduction(+:sq)
    for(int i=0;i<n;i++){double d=a[i]-mean;sq+=d*d;}
    printf("mean=%.3f population_stddev=%.3f\n",mean,sqrt(sq/n));
    return 0;
}
