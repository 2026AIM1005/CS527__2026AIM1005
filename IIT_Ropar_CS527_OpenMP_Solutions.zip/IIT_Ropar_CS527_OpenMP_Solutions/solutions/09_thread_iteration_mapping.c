#include <stdio.h>
#include <omp.h>
int main(void) {
    omp_set_num_threads(4);
    printf("Static schedule:\n");
    #pragma omp parallel for schedule(static,2)
    for(int i=0;i<16;i++)
        printf("iteration %2d -> thread %d\n",i,omp_get_thread_num());
    printf("\nDynamic schedule:\n");
    #pragma omp parallel for schedule(dynamic,2)
    for(int i=0;i<16;i++)
        printf("iteration %2d -> thread %d\n",i,omp_get_thread_num());
    return 0;
}
