#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#define LIMIT 100000
int main(void){
    char *prime=malloc((LIMIT+1)*sizeof(char));
    for(int i=0;i<=LIMIT;i++)prime[i]=1;
    prime[0]=prime[1]=0;
    for(int p=2;p*p<=LIMIT;p++)if(prime[p]){
        #pragma omp parallel for schedule(static)
        for(int j=p*p;j<=LIMIT;j+=p)prime[j]=0;
    }
    int count=0;
    #pragma omp parallel for reduction(+:count)
    for(int i=2;i<=LIMIT;i++)if(prime[i])count++;
    printf("Number of primes <= %d: %d\n",LIMIT,count);
    free(prime);
    return 0;
}
