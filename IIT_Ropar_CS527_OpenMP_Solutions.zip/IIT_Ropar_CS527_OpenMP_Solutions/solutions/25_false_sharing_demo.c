#include <stdio.h>
#include <omp.h>
#define N 8
#define REPS 10000000
typedef struct { volatile long long value; } Counter;
typedef struct { volatile long long value; char pad[64-sizeof(long long)]; } PaddedCounter;
int main(void){
    Counter c[N]={0}; PaddedCounter p[N]={0};
    double t=omp_get_wtime();
    #pragma omp parallel for
    for(int i=0;i<N;i++)for(int j=0;j<REPS;j++)c[i].value++;
    double a=omp_get_wtime()-t;
    t=omp_get_wtime();
    #pragma omp parallel for
    for(int i=0;i<N;i++)for(int j=0;j<REPS;j++)p[i].value++;
    double b=omp_get_wtime()-t;
    printf("compact counters %.6f s; padded counters %.6f s\n",a,b);
    puts("Timing is hardware/compiler dependent; this is an illustrative false-sharing experiment.");
    return 0;
}
