#include <stdio.h>
#include <stdlib.h>
#include <omp.h>
#define N 20
#define CUTOFF 256
void merge(int a[],int l,int m,int r){
    int n1=m-l+1,n2=r-m;
    int *x=malloc((size_t)n1*sizeof(int)),*y=malloc((size_t)n2*sizeof(int));
    for(int i=0;i<n1;i++)x[i]=a[l+i];
    for(int j=0;j<n2;j++)y[j]=a[m+1+j];
    int i=0,j=0,k=l;
    while(i<n1&&j<n2)a[k++]=(x[i]<=y[j])?x[i++]:y[j++];
    while(i<n1)a[k++]=x[i++];
    while(j<n2)a[k++]=y[j++];
    free(x);free(y);
}
void sort_task(int a[],int l,int r){
    if(r-l+1<=CUTOFF){
        for(int i=l+1;i<=r;i++){int key=a[i],j=i-1;while(j>=l&&a[j]>key){a[j+1]=a[j];j--;}a[j+1]=key;}
        return;
    }
    int m=l+(r-l)/2;
    #pragma omp task shared(a) firstprivate(l,m)
    sort_task(a,l,m);
    #pragma omp task shared(a) firstprivate(m,r)
    sort_task(a,m+1,r);
    #pragma omp taskwait
    merge(a,l,m,r);
}
int main(void){
    int a[N]={19,4,12,7,2,18,1,15,9,3,14,6,20,8,5,17,11,10,16,13};
    #pragma omp parallel
    #pragma omp single
    sort_task(a,0,N-1);
    for(int i=0;i<N;i++)printf("%d ",a[i]);
    puts("");
    return 0;
}
