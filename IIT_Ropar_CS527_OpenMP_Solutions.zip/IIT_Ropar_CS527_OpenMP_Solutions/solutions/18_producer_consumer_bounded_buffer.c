#include <stdio.h>
#include <omp.h>
#define CAP 4
#define ITEMS 20
int main(void){
    int buffer[CAP], count=0, in=0, out=0, produced=0, consumed=0;
    omp_lock_t lock;
    omp_init_lock(&lock);
    #pragma omp parallel sections num_threads(2) shared(buffer,count,in,out,produced,consumed,lock)
    {
        #pragma omp section
        {
            for(int x=1;x<=ITEMS;){
                omp_set_lock(&lock);
                if(count<CAP){
                    buffer[in]=x; in=(in+1)%CAP; count++; produced++; x++;
                }
                omp_unset_lock(&lock);
            }
        }
        #pragma omp section
        {
            while(consumed<ITEMS){
                omp_set_lock(&lock);
                if(count>0){
                    int value=buffer[out]; out=(out+1)%CAP; count--; consumed++;
                    printf("consumed %d\n",value);
                }
                omp_unset_lock(&lock);
            }
        }
    }
    printf("produced=%d consumed=%d remaining=%d\n",produced,consumed,count);
    omp_destroy_lock(&lock);
    return 0;
}
