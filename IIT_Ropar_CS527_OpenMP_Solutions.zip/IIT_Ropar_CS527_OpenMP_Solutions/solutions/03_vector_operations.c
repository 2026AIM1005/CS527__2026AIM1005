#include <stdio.h>
#include <omp.h>
#define N 8
int main(void) {
    double a[N], b[N], add[N], sub[N], mul[N];
    double dot = 0.0;
    #pragma omp parallel for
    for (int i = 0; i < N; ++i) { a[i] = i + 1; b[i] = 2*(i + 1); }
    #pragma omp parallel for reduction(+:dot)
    for (int i = 0; i < N; ++i) {
        add[i] = a[i] + b[i];
        sub[i] = a[i] - b[i];
        mul[i] = a[i] * b[i];
        dot += a[i] * b[i];
    }
    printf("dot product = %.0f\n", dot);
    for (int i = 0; i < N; ++i)
        printf("%d: add=%.0f sub=%.0f mul=%.0f\n", i, add[i], sub[i], mul[i]);
    return 0;
}
