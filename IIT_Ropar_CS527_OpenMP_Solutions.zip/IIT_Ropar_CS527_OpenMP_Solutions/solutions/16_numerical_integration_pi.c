#include <stdio.h>
#include <omp.h>
int main(void){
    const long long steps=10000000;
    double sum=0.0,dx=1.0/(double)steps;
    double t=omp_get_wtime();
    #pragma omp parallel for reduction(+:sum) schedule(static)
    for(long long i=0;i<steps;i++){
        double x=(i+0.5)*dx;
        sum+=4.0/(1.0+x*x);
    }
    double pi=sum*dx;
    printf("pi=%.12f time=%.6f s\n",pi,omp_get_wtime()-t);
    return 0;
}
