#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n < 0) return 0;
    vector<long long> price(n);
    for (auto &x : price) if (!(cin >> x)) return 0;
    if (n == 0) {
        cout << "Maximum profit: 0\n";
        return 0;
    }

    long long hold = -price[0], sold = LLONG_MIN / 4, rest = 0;
    for (int i = 1; i < n; ++i) {
        long long newHold = max(hold, rest - price[i]);
        long long newSold = hold + price[i];
        long long newRest = max(rest, sold);
        hold = newHold;
        sold = newSold;
        rest = newRest;
    }

    cout << "Maximum profit: " << max(rest, sold) << '\n';
    return 0;
}
