#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n <= 0) return 0;
    vector<long long> a(n), dp(n);
    for (auto &x : a) if (!(cin >> x)) return 0;

    int bestEnd = 0;
    for (int i = 0; i < n; ++i) {
        dp[i] = a[i];
        for (int j = 0; j < i; ++j) {
            if (a[j] < a[i] && dp[j] + a[i] > dp[i])
                dp[i] = dp[j] + a[i];
        }
        if (dp[i] > dp[bestEnd]) bestEnd = i;
    }

    cout << "Maximum sum: " << dp[bestEnd] << '\n';
    return 0;
}
