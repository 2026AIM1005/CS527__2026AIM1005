#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    if (!(cin >> s)) return 0;
    int n = (int)s.size();
    vector<vector<bool>> pal(n, vector<bool>(n, false));

    for (int i = n - 1; i >= 0; --i) {
        for (int j = i; j < n; ++j) {
            pal[i][j] = (s[i] == s[j]) && (j - i < 2 || pal[i + 1][j - 1]);
        }
    }

    const int INF = 1e9;
    vector<int> dp(n + 1, INF), prev(n + 1, -1);
    dp[0] = -1;
    for (int end = 1; end <= n; ++end) {
        for (int start = 0; start < end; ++start) {
            if (pal[start][end - 1] && dp[start] + 1 < dp[end]) {
                dp[end] = dp[start] + 1;
                prev[end] = start;
            }
        }
    }

    vector<string> parts;
    for (int end = n; end > 0; end = prev[end])
        parts.push_back(s.substr(prev[end], end - prev[end]));
    reverse(parts.begin(), parts.end());

    cout << "Minimum cuts: " << max(0, dp[n]) << '\n';
    cout << "Partitions: ";
    for (int i = 0; i < (int)parts.size(); ++i) {
        if (i) cout << " | ";
        cout << parts[i];
    }
    cout << '\n';
    return 0;
}
