#include <bits/stdc++.h>
using namespace std;

long long largestHistogram(const vector<int>& h) {
    int n = (int)h.size();
    stack<int> st;
    long long best = 0;
    for (int i = 0; i <= n; ++i) {
        int current = (i == n ? 0 : h[i]);
        while (!st.empty() && h[st.top()] >= current) {
            int height = h[st.top()];
            st.pop();
            int width = st.empty() ? i : i - st.top() - 1;
            best = max(best, 1LL * height * width);
        }
        st.push(i);
    }
    return best;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int rows, cols;
    if (!(cin >> rows >> cols) || rows < 0 || cols < 0) return 0;
    vector<int> heights(cols, 0);
    long long answer = 0;

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            int x;
            if (!(cin >> x) || (x != 0 && x != 1)) {
                cout << "Invalid input\n";
                return 0;
            }
            heights[j] = (x == 0 ? 0 : heights[j] + 1);
        }
        answer = max(answer, largestHistogram(heights));
    }

    cout << "Maximum rectangle area: " << answer << '\n';
    return 0;
}
