#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, capacity;
    if (!(cin >> n >> capacity) || n < 0 || capacity < 0) return 0;
    vector<long long> value(n);
    vector<int> weight(n);
    for (int i = 0; i < n; ++i) {
        if (!(cin >> value[i] >> weight[i]) || weight[i] <= 0) {
            cout << "Invalid input\n";
            return 0;
        }
    }

    vector<long long> dp(capacity + 1, 0);
    for (int w = 0; w <= capacity; ++w) {
        for (int i = 0; i < n; ++i) {
            if (weight[i] <= w)
                dp[w] = max(dp[w], value[i] + dp[w - weight[i]]);
        }
    }

    cout << "Maximum Value: " << dp[capacity] << '\n';
    return 0;
}
