#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n <= 0) return 0;
    long long x;
    if (!(cin >> x)) return 0;

    long long bestEnding = x, worstEnding = x, answer = x;
    for (int i = 1; i < n; ++i) {
        if (!(cin >> x)) return 0;
        if (x < 0) swap(bestEnding, worstEnding);
        bestEnding = max(x, bestEnding * x);
        worstEnding = min(x, worstEnding * x);
        answer = max(answer, bestEnding);
    }

    cout << "Maximum product: " << answer << '\n';
    return 0;
}
