#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n <= 0 || n > 20) return 0;
    vector<vector<long long>> cost(n, vector<long long>(n));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            if (!(cin >> cost[i][j])) return 0;
        }
    }

    const long long INF = LLONG_MAX / 4;
    int totalMasks = 1 << n;
    vector<vector<long long>> dp(totalMasks, vector<long long>(n, INF));
    dp[1][0] = 0;

    for (int mask = 1; mask < totalMasks; ++mask) {
        if (!(mask & 1)) continue;
        for (int u = 0; u < n; ++u) {
            if (!(mask & (1 << u)) || dp[mask][u] == INF) continue;
            for (int v = 0; v < n; ++v) {
                if (mask & (1 << v)) continue;
                int nextMask = mask | (1 << v);
                dp[nextMask][v] = min(dp[nextMask][v], dp[mask][u] + cost[u][v]);
            }
        }
    }

    long long answer = INF;
    for (int u = 0; u < n; ++u)
        answer = min(answer, dp[totalMasks - 1][u] + cost[u][0]);

    cout << "Minimum tour cost: " << answer << '\n';
    return 0;
}
