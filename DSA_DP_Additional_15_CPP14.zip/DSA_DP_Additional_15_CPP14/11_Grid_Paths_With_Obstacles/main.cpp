#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int rows, cols;
    if (!(cin >> rows >> cols) || rows <= 0 || cols <= 0) return 0;
    vector<vector<int>> grid(rows, vector<int>(cols));
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            if (!(cin >> grid[i][j]) || (grid[i][j] != 0 && grid[i][j] != 1)) {
                cout << "Invalid input\n";
                return 0;
            }
        }
    }

    vector<vector<unsigned long long>> dp(rows, vector<unsigned long long>(cols, 0));
    if (grid[0][0] == 0) dp[0][0] = 1;
    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            if (grid[i][j] == 1) {
                dp[i][j] = 0;
                continue;
            }
            if (i > 0) dp[i][j] += dp[i - 1][j];
            if (j > 0) dp[i][j] += dp[i][j - 1];
        }
    }

    cout << "Number of paths: " << dp[rows - 1][cols - 1] << '\n';
    return 0;
}
