#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int eggs;
    long long floors;
    if (!(cin >> eggs >> floors) || eggs <= 0 || floors < 0) return 0;

    vector<unsigned long long> reach(eggs + 1, 0);
    long long moves = 0;
    while (reach[eggs] < (unsigned long long)floors) {
        ++moves;
        for (int e = eggs; e >= 1; --e) {
            unsigned long long value = reach[e] + reach[e - 1] + 1;
            reach[e] = min(value, (unsigned long long)floors);
        }
    }

    cout << "Minimum number of trials in worst case: " << moves << '\n';
    return 0;
}
