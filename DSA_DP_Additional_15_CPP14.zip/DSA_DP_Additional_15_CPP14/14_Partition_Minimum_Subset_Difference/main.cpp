#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n < 0) return 0;
    vector<int> a(n);
    long long total = 0;
    for (int &x : a) {
        if (!(cin >> x) || x < 0) {
            cout << "Invalid input\n";
            return 0;
        }
        total += x;
    }

    long long half = total / 2;
    if (half > 2000000) {
        cout << "Total sum too large for this DP implementation\n";
        return 0;
    }
    vector<char> dp((int)half + 1, false);
    dp[0] = true;
    for (int x : a) {
        for (int s = (int)half; s >= x; --s)
            if (dp[s - x]) dp[s] = true;
    }

    int best = 0;
    for (int s = (int)half; s >= 0; --s) {
        if (dp[s]) {
            best = s;
            break;
        }
    }

    cout << "Minimum subset sum difference: " << total - 2LL * best << '\n';
    return 0;
}
