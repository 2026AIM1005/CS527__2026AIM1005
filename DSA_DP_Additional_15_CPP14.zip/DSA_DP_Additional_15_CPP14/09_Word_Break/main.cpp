#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    int n;
    if (!(cin >> s >> n) || n < 0) return 0;
    unordered_set<string> words;
    int maxLength = 0;
    for (int i = 0; i < n; ++i) {
        string word;
        if (!(cin >> word)) return 0;
        words.insert(word);
        maxLength = max(maxLength, (int)word.size());
    }

    int len = (int)s.size();
    vector<bool> dp(len + 1, false);
    vector<int> parent(len + 1, -1);
    dp[0] = true;

    for (int i = 1; i <= len; ++i) {
        for (int j = max(0, i - maxLength); j < i; ++j) {
            if (dp[j] && words.count(s.substr(j, i - j))) {
                dp[i] = true;
                parent[i] = j;
                break;
            }
        }
    }

    if (!dp[len]) {
        cout << "Cannot be segmented\n";
        return 0;
    }

    vector<string> result;
    for (int i = len; i > 0; i = parent[i])
        result.push_back(s.substr(parent[i], i - parent[i]));
    reverse(result.begin(), result.end());

    cout << "Can be segmented\n";
    cout << "Segmentation: ";
    for (int i = 0; i < (int)result.size(); ++i) {
        if (i) cout << ' ';
        cout << result[i];
    }
    cout << '\n';
    return 0;
}
