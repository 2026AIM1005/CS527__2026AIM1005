#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n < 0) return 0;
    vector<int> a(n);
    for (int &x : a) {
        if (!(cin >> x) || x < 0) {
            cout << "Invalid input\n";
            return 0;
        }
    }
    if (n <= 1) {
        cout << "Minimum jumps: 0\n";
        return 0;
    }

    const int INF = 1e9;
    vector<int> dp(n, INF), parent(n, -1);
    dp[0] = 0;
    for (int i = 0; i < n; ++i) {
        if (dp[i] == INF) continue;
        for (int j = i + 1; j < n && j <= i + a[i]; ++j) {
            if (dp[i] + 1 < dp[j]) {
                dp[j] = dp[i] + 1;
                parent[j] = i;
            }
        }
    }

    if (dp[n - 1] == INF) {
        cout << "Destination cannot be reached\n";
        return 0;
    }

    vector<int> path;
    for (int at = n - 1; at != -1; at = parent[at]) path.push_back(at);
    reverse(path.begin(), path.end());

    cout << "Minimum jumps: " << dp[n - 1] << '\n';
    cout << "Path indices: ";
    for (int i = 0; i < (int)path.size(); ++i) {
        if (i) cout << ' ';
        cout << path[i];
    }
    cout << '\n';
    return 0;
}
