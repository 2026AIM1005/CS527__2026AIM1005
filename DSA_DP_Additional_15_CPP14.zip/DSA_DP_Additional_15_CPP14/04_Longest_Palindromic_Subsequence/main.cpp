#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string s;
    if (!(cin >> s)) return 0;
    int n = (int)s.size();
    vector<vector<int>> dp(n, vector<int>(n, 0));

    for (int i = n - 1; i >= 0; --i) {
        dp[i][i] = 1;
        for (int j = i + 1; j < n; ++j) {
            if (s[i] == s[j])
                dp[i][j] = 2 + (j == i + 1 ? 0 : dp[i + 1][j - 1]);
            else
                dp[i][j] = max(dp[i + 1][j], dp[i][j - 1]);
        }
    }

    string left, right;
    int i = 0, j = n - 1;
    while (i <= j) {
        if (i == j) {
            left.push_back(s[i]);
            break;
        }
        int inner = (j == i + 1 ? 0 : dp[i + 1][j - 1]);
        if (s[i] == s[j] && dp[i][j] == inner + 2) {
            left.push_back(s[i]);
            right.push_back(s[j]);
            ++i;
            --j;
        } else if (dp[i + 1][j] >= dp[i][j - 1]) ++i;
        else --j;
    }
    reverse(right.begin(), right.end());

    cout << "Length: " << dp[0][n - 1] << '\n';
    cout << "Longest palindromic subsequence: " << left + right << '\n';
    return 0;
}
