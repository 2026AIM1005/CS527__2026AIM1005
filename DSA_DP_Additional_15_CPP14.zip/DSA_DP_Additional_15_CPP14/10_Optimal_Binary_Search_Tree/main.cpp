#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    if (!(cin >> n) || n < 0) return 0;
    vector<long long> key(n), freq(n);
    for (auto &x : key) if (!(cin >> x)) return 0;
    for (auto &x : freq) {
        if (!(cin >> x) || x < 0) {
            cout << "Invalid input\n";
            return 0;
        }
    }
    for (int i = 1; i < n; ++i) {
        if (key[i] <= key[i - 1]) {
            cout << "Keys must be in strictly increasing order\n";
            return 0;
        }
    }

    vector<vector<long long>> dp(n, vector<long long>(n, 0));
    vector<vector<int>> root(n, vector<int>(n, -1));
    vector<long long> prefix(n + 1, 0);
    for (int i = 0; i < n; ++i) prefix[i + 1] = prefix[i] + freq[i];

    for (int len = 1; len <= n; ++len) {
        for (int i = 0; i + len <= n; ++i) {
            int j = i + len - 1;
            long long sum = prefix[j + 1] - prefix[i];
            dp[i][j] = LLONG_MAX;
            for (int r = i; r <= j; ++r) {
                long long left = (r == i ? 0 : dp[i][r - 1]);
                long long right = (r == j ? 0 : dp[r + 1][j]);
                long long cost = left + right + sum;
                if (cost < dp[i][j]) {
                    dp[i][j] = cost;
                    root[i][j] = r;
                }
            }
        }
    }

    cout << "Minimum search cost: " << (n == 0 ? 0 : dp[0][n - 1]) << '\n';
    if (n > 0) cout << "Root key: " << key[root[0][n - 1]] << '\n';
    return 0;
}
