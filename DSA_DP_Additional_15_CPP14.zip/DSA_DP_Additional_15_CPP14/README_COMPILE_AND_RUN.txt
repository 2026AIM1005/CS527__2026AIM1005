DSA DP LAB EXAM - ADDITIONAL 15 PROGRAMS (C++14)
=================================================

This package contains 15 independent C++14 programs. Each program reads
runtime input from standard input; sample values are not embedded in code.
All source files are written without explanatory comments.

PROGRAMS
--------
01 Unbounded Knapsack
02 Minimum Jumps to Reach End
03 Maximum Product Subarray
04 Longest Palindromic Subsequence
05 Palindrome Partitioning (minimum cuts)
06 Egg Dropping (minimum worst-case trials)
07 Maximum Sum Increasing Subsequence
08 Wildcard Pattern Matching
09 Word Break
10 Optimal Binary Search Tree
11 Grid Paths with Obstacles
12 Maximum Rectangle of Ones in a Binary Matrix
13 Stock Buy/Sell with Cooldown
14 Partition into Two Subsets with Minimum Difference
15 Travelling Salesman using Bitmask DP

COMPILE AND RUN
---------------
Windows PowerShell (MinGW):
  g++ -std=c++14 -O2 -Wall -Wextra main.cpp -o main.exe
  .\main.exe

Linux:
  g++ -std=c++14 -O2 -Wall -Wextra main.cpp -o main
  ./main

Input redirection:
  Windows: .\main.exe < input.txt
  Linux:   ./main < input.txt

INPUT FORMATS
-------------

01 Unbounded Knapsack
  N capacity
  N lines: value weight
  An item can be selected any number of times. Weights must be positive.

02 Minimum Jumps
  N
  N non-negative maximum jump lengths

03 Maximum Product Subarray
  N
  N integers (N must be at least 1)

04 Longest Palindromic Subsequence
  One non-empty string

05 Palindrome Partitioning
  One non-empty string. Prints minimum cuts and one partition.

06 Egg Dropping
  eggs floors
  eggs must be positive; floors must be non-negative.

07 Maximum Sum Increasing Subsequence
  N
  N integers (N must be at least 1)

08 Wildcard Pattern Matching
  text pattern
  '?' matches one character; '*' matches any sequence, including empty.

09 Word Break
  string
  dictionary_size
  dictionary words
  Example:
  catsanddog
  5
  cats cat and sand dog

10 Optimal Binary Search Tree
  N
  N sorted distinct keys
  N non-negative search frequencies
  Uses successful-search frequencies only (no unsuccessful-search probabilities).

11 Grid Paths with Obstacles
  rows columns
  grid entries (0 = free cell, 1 = blocked cell)
  Moves allowed only right and down.

12 Maximum Rectangle of Ones
  rows columns
  binary matrix entries (0 or 1)

13 Stock Buy/Sell with Cooldown
  N
  N daily prices
  After selling, one full day cooldown applies.

14 Partition Minimum Difference
  N
  N non-negative integers
  The implementation uses a subset-sum DP and limits half the total sum to 2,000,000.

15 Travelling Salesman (Bitmask DP)
  N
  N x N cost matrix
  Starts at vertex 0, visits each vertex once, and returns to vertex 0.
  N is limited to 20 due to exponential time and memory.

IMPORTANT LIMITS
----------------
- TSP bitmask DP is exponential; keep N small (at most 20, preferably much smaller).
- Subset-sum based partition DP is pseudo-polynomial and checks the sum limit.
- DP table memory/time depends on input dimensions.
- Inputs must follow the format for the selected folder exactly.
